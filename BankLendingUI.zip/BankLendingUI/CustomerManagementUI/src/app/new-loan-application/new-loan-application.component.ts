import { Component } from '@angular/core';
import { LoanApplication } from '../loan-application';
import { Customer } from '../customer';
import { Router } from '@angular/router';
import { CustomerService } from '../customer.service';
import { LoanApplicationService } from '../loan-application.service';
import { formatDate } from '@angular/common';

@Component({
  selector: 'app-new-loan-application',
  templateUrl: './new-loan-application.component.html',
  styleUrls: ['./new-loan-application.component.css']
})
export class NewLoanApplicationComponent {
  loanApplication: LoanApplication = new LoanApplication();
  submitted = false;
  customers!: Customer[];
  loanYears: number[] = [];
  loanTypes: string[] = ['Home Loan', 'Auto Loan', 'Business Loan', 'Education Loan', 'Mortgage Loan'];

  constructor(private router: Router, private customerService: CustomerService, private loanApplicationService: LoanApplicationService) { }

  ngOnInit() {
    this.customerService.getAllCustomers()
    .subscribe( data => {
      this.customers = data;
      console.log(data);
    },error=>console.log(error));

    this.populateLoanYears();
  }

  newIntern(): void {
    this.submitted = false;
    this.loanYears=[];
    this.loanApplication = new LoanApplication();
  }

  populateLoanYears() { 
    for (let year = 1; year <= 30; year++) { 
      this.loanYears.push(year); 
    } 
  }

  save() {
    this.loanApplicationService.addLoanApplication(this.loanApplication)
      .subscribe(data =>{ 
        console.log(data);
        this.submitted = true;
        this.loanApplication = new LoanApplication();
      }, error => console.log(error));
    // this.loanApplication = new LoanApplication();
  }

  onSubmit() {
    // this.submitted = true;
    this.save();
  }

  isCurrentDate(date: string): boolean { 
    if (!date) { 
      return false; // Return false if the date is not defined 
    } 
    const today = new Date().toISOString().split('T')[0]; 
    return today === date; 
  }
}
