import { TestBed } from '@angular/core/testing';

import { AuthGuardBankerService } from './auth-guard-banker.service';

describe('AuthGuardBankerService', () => {
  let service: AuthGuardBankerService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AuthGuardBankerService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
