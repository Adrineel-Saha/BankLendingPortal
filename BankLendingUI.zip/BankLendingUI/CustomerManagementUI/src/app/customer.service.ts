import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Customer } from './customer';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  constructor(private http:HttpClient) { }

  private addCustomerURL="http://localhost:8080/api/customers/new";
  private updateCustomerURL="http://localhost:8080/api/customers";
  private getCustomerByIdUrl="http://localhost:8080/api/customers";
  private getAllCustomersUrl="http://localhost:8080/api/customers";

  public addCustomer(customer:Customer){
    return this.http.post<Customer>(this.addCustomerURL,customer);
  }

  public getCustomerById(custId:string){
    return this.http.get<Customer>(this.getCustomerByIdUrl+"/"+custId);
  }

  public updateCustomer(custId:string,customer:Customer){
    return this.http.put<Customer>(this.updateCustomerURL+"/"+custId+"/update",customer);
  }

  public getAllCustomers(){
    return this.http.get<Customer[]>(this.getAllCustomersUrl);
  }
}
