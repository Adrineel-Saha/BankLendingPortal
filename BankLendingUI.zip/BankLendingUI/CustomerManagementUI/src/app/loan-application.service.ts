import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { LoanApplication } from './loan-application';

@Injectable({
  providedIn: 'root'
})
export class LoanApplicationService {

  constructor(private http:HttpClient) { }

  private addLoanApplicationUrl="http://localhost:8080/api/customers/loan/new";
  private updateLoanApplicationUrl="http://localhost:8080/api/customers/loan";
  private getLoanApplicationByIdUrl="http://localhost:8080/api/customers/loan";

  public addLoanApplication(loanApplication:LoanApplication){
    return this.http.post<LoanApplication>(this.addLoanApplicationUrl,loanApplication);
  }

  public getLoanApplicationById(loanAppId:string){
    return this.http.get<LoanApplication>(this.getLoanApplicationByIdUrl+"/"+loanAppId,{headers :new HttpHeaders({ 'Request-Type': 'LoanAppId' })});
  }

  public updateLoanApplication(loanAppId:string,loanApplication:LoanApplication){
    return this.http.put<LoanApplication>(this.updateLoanApplicationUrl+"/"+loanAppId+"/update",loanApplication);
  }
}
