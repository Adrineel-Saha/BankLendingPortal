import { Component } from '@angular/core';
import { Customer } from '../customer';
import { Router } from '@angular/router';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-update-customer',
  templateUrl: './update-customer.component.html',
  styleUrls: ['./update-customer.component.css']
})
export class UpdateCustomerComponent {
  customer: Customer=new Customer();
  submitted = false;
  adharCardDuplicate = false;
  showForm = false;
  showFormInitial = true;
  isCustomerAbsent = false;

  constructor(private router: Router, private customerService:CustomerService) {  
  }

  ngOnInit() {
  }

  newIntern(): void {
    this.submitted = false;
    this.adharCardDuplicate = false;
    this.showForm = false;
    this.showFormInitial = true;
    this.isCustomerAbsent = false;
    this.customer = new Customer();
  }

  getCustomerById() {
     if (this.customer.custId) { 
      this.customerService.getCustomerById(this.customer.custId).subscribe(data => { 
        this.showFormInitial = false;
        this.customer = data; 
        this.showForm = true; 
        this.isCustomerAbsent = false;
        // Show form after fetching details 
        }, error => {
          if (error.status === 400) { 
            this.isCustomerAbsent = true; 
            this.showFormInitial = true;
            setTimeout(() => { 
              this.customer = new Customer();
              this.isCustomerAbsent = false; 
            }, 3000);
          } else { 
            console.log(error); 
          }
        }); 
      } 
    }
  
  save() {
    this.customerService.updateCustomer(this.customer.custId,this.customer)
      .subscribe(data => {
        console.log(data);
        this.submitted=true;
        this.customer = new Customer();
      }, error => {
        if (error.status === 409) { 
          this.adharCardDuplicate = true; 
          setTimeout(() => { 
            // this.customer.adharCard;
            this.adharCardDuplicate = false; 
          }, 3000);
        } else { 
          console.log(error); 
        }
      });
      // this.customer = new Customer();
  }

  onSubmit() {
    // this.submitted = true;
    this.save();
  }

  validateAge(control:any): void { 
    const birthDate = new Date(control.value); 
    const today = new Date(); 
    let age = today.getFullYear() - birthDate.getFullYear(); 
    const m = today.getMonth() - birthDate.getMonth(); 
    
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) { 
      age--; 
    } 
    
    if (age < 18 || age > 58) { 
      control.control.setErrors({ 'age': true }); 
    } 
    else { 
      control.control.setErrors(null); 
    } 
  }
}
