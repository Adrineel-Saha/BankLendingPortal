export class LoanApplication {
    loanAppId!: string;
    custId!: string;
    loanAmt!: number;
    noOfYears!: number;
    purpose!: string;
    appStatus!: string;
    typeOfLoan!: string;
    loanAppDate!: Date;
    status!: string;
}
