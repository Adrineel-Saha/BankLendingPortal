export class Customer {
    
    custId!: string;
    custFirstName!: string;
    custLastName!: string;
    address!: string;
    city!: string;
    contactNo!: number;
    adharCard!: number;
    emailId!: string;
    birthDate!: Date;
    monthlySalary!: number;
}
