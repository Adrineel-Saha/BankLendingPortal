import { Component } from '@angular/core';
import { LoanApplication } from '../loan-application';
import { Router } from '@angular/router';
import { LoanApplicationService } from '../loan-application.service';

@Component({
  selector: 'app-update-loan-application',
  templateUrl: './update-loan-application.component.html',
  styleUrls: ['./update-loan-application.component.css']
})
export class UpdateLoanApplicationComponent {
  loanApplication: LoanApplication = new LoanApplication();
  submitted = false;
  // customers!: Customer[];
  loanYears: number[] = [];
  loanTypes: string[] = ['Home Loan', 'Auto Loan', 'Business Loan', 'Education Loan', 'Mortgage Loan'];
  statusOptions: string[] = ['accepted', 'rejected'];
  showForm = false;
  showFormInitial = true;
  isLoanApplicationAbsent = false;
  isStatusNewLoan = false; 
  isStatusApproved = false;

  constructor(private router: Router, private loanApplicationService: LoanApplicationService) { }

  ngOnInit() {
    // this.customerService.getAllCustomers()
    // .subscribe( data => {
    //   this.customers = data;
    //   console.log(data);
    // },error=>console.log(error));

    this.populateLoanYears();
  }

  newIntern(): void {
    this.submitted = false;
    this.loanYears=[];
    this.showForm = false;
    this.showFormInitial = true;
    this.isLoanApplicationAbsent = false;
    this.isStatusNewLoan = false; 
    this.isStatusApproved = false;
    this.loanApplication = new LoanApplication();
  }

  getLoanApplicationById() { 
    if(this.loanApplication.loanAppId){
      this.loanApplicationService.getLoanApplicationById(this.loanApplication.loanAppId).
      subscribe( data => { 
        // else{
        this.loanApplication = data; 
        this.showFormInitial = false; 
        this.showForm = true; 
        this.isStatusNewLoan = this.loanApplication.appStatus === 'NewLoan'; 
        this.isStatusApproved = this.loanApplication.appStatus === 'Approved';
        // } 
        if(!this.isStatusNewLoan && !this.isStatusApproved){
          alert("Customer can't update loan record");
          // this.loanApplication.loanAppId='';
          this.showFormInitial = true; 
          this.showForm = false;
          // this.loanApplication=new LoanApplication();
          setTimeout(() => { 
            this.loanApplication = new LoanApplication();
            this.isLoanApplicationAbsent = false; 
          }, 3000);
        }    
      }, 
        error => {
          if (error.status === 400) { 
            // console.log(error.status);
            this.isLoanApplicationAbsent = true; 
            this.showFormInitial = true;
            // this.loanApplication=new LoanApplication();
            setTimeout(() => { 
              this.loanApplication = new LoanApplication();
              this.isLoanApplicationAbsent = false; 
            }, 3000);
          } else { 
            console.log(error); 
          } } );
    }
 }

  populateLoanYears() { 
    for (let year = 1; year <= 30; year++) { 
      this.loanYears.push(year); 
    } 
  }

  save() { 
    // if (this.isStatusNewLoan || this.isStatusApproved) { 
      this.loanApplicationService.updateLoanApplication(this.loanApplication.loanAppId,this.loanApplication).
      subscribe( data => { 
        console.log(data); 
        this.submitted = true;
        this.loanApplication=new LoanApplication();
       }, error =>console.error(error)); 
    // } 
    // else { 
    //   alert("Customer can't update loan record");
    //   // console.log("Update not allowed for this status"); 
    // } 
  }

  onSubmit() {
    // this.submitted = true;
    this.save();
  }

  // isCurrentDate(date: string): boolean { 
  //   if (!date) { 
  //     return false; // Return false if the date is not defined 
  //   } 
  //   const today = new Date().toISOString().split('T')[0]; 
  //   return today === date; 
  // }
}
