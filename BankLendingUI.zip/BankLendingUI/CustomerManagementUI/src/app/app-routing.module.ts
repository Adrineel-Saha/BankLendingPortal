import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CreateCustomerComponent } from './create-customer/create-customer.component';
import { NavigationComponent } from './navigation/navigation.component';
import { UpdateCustomerComponent } from './update-customer/update-customer.component';
import { NewLoanApplicationComponent } from './new-loan-application/new-loan-application.component';
import { UpdateLoanApplicationComponent } from './update-loan-application/update-loan-application.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { AuthGuardCustomerService } from './service/auth-guard-customer.service';
import { AuthGuardBankerService } from './service/auth-guard-banker.service';
import { AppComponent } from './app.component';

const routes: Routes = [
  {path: 'createCustomer', component: CreateCustomerComponent,canActivate:[AuthGuardCustomerService] },
  {path: 'updateCustomer', component: UpdateCustomerComponent,canActivate:[AuthGuardCustomerService] },
  {path: 'newLoanApplication', component: NewLoanApplicationComponent,canActivate:[AuthGuardBankerService] },
  {path: 'updateLoanApplication', component: UpdateLoanApplicationComponent,canActivate:[AuthGuardCustomerService] },
  {path: 'login', component: LoginComponent},
  {path: 'logout', component: LogoutComponent },
  // { path: 'app', component: AppComponent },
  {path: 'navigation',component: NavigationComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
