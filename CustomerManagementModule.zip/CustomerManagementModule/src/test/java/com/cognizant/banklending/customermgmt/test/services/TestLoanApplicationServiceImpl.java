package com.cognizant.banklending.customermgmt.test.services;

import com.cognizant.banklending.customermgmt.dtos.LoanAppDTO;
import com.cognizant.banklending.customermgmt.entities.CustomerMaster;
import com.cognizant.banklending.customermgmt.entities.LoanApplication;
import com.cognizant.banklending.customermgmt.repositories.CustomerMasterRepository;
import com.cognizant.banklending.customermgmt.repositories.LoanApplicationRepository;
import com.cognizant.banklending.customermgmt.services.LoanApplicationServiceImpl;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.modelmapper.ModelMapper;

import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class TestLoanApplicationServiceImpl {
    @Mock
    private LoanApplicationRepository loanApplicationRepository;

    @Mock
    private CustomerMasterRepository customerMasterRepository;

    @Mock
    private ModelMapper modelMapper;

    @InjectMocks
    private LoanApplicationServiceImpl loanApplicationServiceImpl;

    @BeforeEach
    void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
    }

    @AfterEach
    void tearDown() throws Exception {

    }

    @Test
    public void testGetLoanApplicationByIdPositive(){
        try{
            LoanApplication loanApplication=new LoanApplication();
            loanApplication.setLoanAppId("LOAN001");
            loanApplication.setLoanAmt(200000);
            loanApplication.setNoOfYears(5);
            loanApplication.setPurpose("Home Renovation");
            loanApplication.setAppStatus("NewLoan");
            loanApplication.setTypeOfLoan("Home Loan");
            loanApplication.setLoanAppDate(new Date());
            loanApplication.setStatus("accepted");

            CustomerMaster customerMaster=new CustomerMaster();

            customerMaster.setCustId("CUST01");
            customerMaster.setCustFirstName("Adrineel");
            customerMaster.setCustLastName("Saha");
            customerMaster.setAddress("123 Street");
            customerMaster.setCity("Asansol");
            customerMaster.setContactNo(1234567890);
            customerMaster.setAdharCard(1456789012);
            customerMaster.setEmailId("adrineel.saha@cognizant.com");
            customerMaster.setBirthDate(new Date(2001,10,18));
            customerMaster.setMonthlySalary(65000);

            loanApplication.setCustomerMaster(customerMaster);

            when(loanApplicationRepository.findById(Mockito.anyString())).thenReturn(Optional.of(loanApplication));

            LoanAppDTO loanAppDTO=new LoanAppDTO();
            loanAppDTO.setLoanAppId("LOAN001");
            loanAppDTO.setCustId("CUST01");
            loanAppDTO.setLoanAmt(200000);
            loanAppDTO.setNoOfYears(5);
            loanAppDTO.setPurpose("Home Renovation");
            loanAppDTO.setAppStatus("NewLoan");
            loanAppDTO.setTypeOfLoan("Home Loan");
            loanAppDTO.setLoanAppDate(new Date());
            loanAppDTO.setStatus("accepted");

            when(modelMapper.map(Mockito.any(LoanApplication.class), Mockito.eq(LoanAppDTO.class))).thenReturn(loanAppDTO);

            LoanAppDTO actualLoanAppDTO=loanApplicationServiceImpl.getLoanApplicationById("LOAN001");
            assertNotNull(actualLoanAppDTO);
        } catch(Exception e){
//            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void testGetLoanApplicationByIdNegative(){
        try{
            when(loanApplicationRepository.findById(Mockito.anyString())).thenReturn(Optional.empty());
//            when(modelMapper.map(Mockito.any(LoanApplication.class), Mockito.eq(LoanAppDTO.class))).thenReturn(null);

            LoanAppDTO actualLoanAppDTO=loanApplicationServiceImpl.getLoanApplicationById("LOAN001");
            assertNotNull(actualLoanAppDTO);
        } catch(Exception e){
//            e.printStackTrace();
            assertTrue(true);
        }
    }

    @Test
    public void testGetLoanApplicationByStatusPositive(){
        try{
            LoanApplication loanApplication=new LoanApplication();
            loanApplication.setLoanAppId("LOAN003");
            loanApplication.setLoanAmt(250000);
            loanApplication.setNoOfYears(7);
            loanApplication.setPurpose("Business Expansion");
            loanApplication.setAppStatus("Sanctioned");
            loanApplication.setTypeOfLoan("Business Loan");
            loanApplication.setLoanAppDate(new Date());
            loanApplication.setStatus("rejected");

            CustomerMaster customerMaster=new CustomerMaster();

            customerMaster.setCustId("CUST03");
            customerMaster.setCustFirstName("Yash");
            customerMaster.setCustLastName("Biswakarma");
            customerMaster.setAddress("789 Boulevard");
            customerMaster.setCity("Darjeeling");
            customerMaster.setContactNo(1122334455);
            customerMaster.setAdharCard(1456701234);
            customerMaster.setEmailId("yash.biswakarma@cognizant.com");
            customerMaster.setBirthDate(new Date(2001,9,29));
            customerMaster.setMonthlySalary(55000);

            loanApplication.setCustomerMaster(customerMaster);

            when(loanApplicationRepository.findById(Mockito.anyString())).thenReturn(Optional.of(loanApplication));

            LoanAppDTO loanAppDTO=new LoanAppDTO();
            loanAppDTO.setLoanAppId("LOAN003");
            loanAppDTO.setCustId("CUST03");
            loanAppDTO.setLoanAmt(250000);
            loanAppDTO.setNoOfYears(7);
            loanAppDTO.setPurpose("Business Expansion");
            loanAppDTO.setAppStatus("Sanctioned");
            loanAppDTO.setTypeOfLoan("Business Loan");
            loanAppDTO.setLoanAppDate(new Date());
            loanAppDTO.setStatus("rejected");

            when(modelMapper.map(Mockito.any(LoanApplication.class), Mockito.eq(LoanAppDTO.class))).thenReturn(loanAppDTO);

            LoanAppDTO actualLoanAppDTO=loanApplicationServiceImpl.getLoanApplicationByStatus("LOAN003");
            assertNotNull(actualLoanAppDTO);
        } catch(Exception e){
//            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void testGetLoanApplicationByStatusNegative(){
        try{
            when(loanApplicationRepository.findById(Mockito.anyString())).thenReturn(Optional.empty());
//            when(modelMapper.map(Mockito.any(LoanApplication.class), Mockito.eq(LoanAppDTO.class))).thenReturn(null);

            LoanAppDTO actualLoanAppDTO=loanApplicationServiceImpl.getLoanApplicationById("LOAN001");
            assertNotNull(actualLoanAppDTO);
        } catch(Exception e){
//            e.printStackTrace();
            assertTrue(true);
        }
    }

    @Test
    public void testGetLoanApplicationByStatusException(){
        try{
            LoanApplication loanApplication=new LoanApplication();
            loanApplication.setLoanAppId("LOAN002");
            loanApplication.setLoanAmt(150000);
            loanApplication.setNoOfYears(3);
            loanApplication.setPurpose("Car Purchase");
            loanApplication.setAppStatus("Approved");
            loanApplication.setTypeOfLoan("Auto Loan");
            loanApplication.setLoanAppDate(new Date());
            loanApplication.setStatus("no status");

            CustomerMaster customerMaster=new CustomerMaster();

            customerMaster.setCustId("CUST02");
            customerMaster.setCustFirstName("Arunabh");
            customerMaster.setCustLastName("Kalita");
            customerMaster.setAddress("456 Avenue");
            customerMaster.setCity("Dibrugarh");
            customerMaster.setContactNo(1876543210);
            customerMaster.setAdharCard(1567890123);
            customerMaster.setEmailId("arunabh.kalita@cognizant.com");
            customerMaster.setBirthDate(new Date(2000,5,15));
            customerMaster.setMonthlySalary(60000);

            loanApplication.setCustomerMaster(customerMaster);

            when(loanApplicationRepository.findById(Mockito.anyString())).thenReturn(Optional.of(loanApplication));

//            LoanAppDTO loanAppDTO=new LoanAppDTO();
//            loanAppDTO.setLoanAppId("LOAN003");
//
//            loanAppDTO.setLoanAmt(250000);
//            loanAppDTO.setNoOfYears(7);
//            loanAppDTO.setPurpose("Business Expansion");
//            loanAppDTO.setAppStatus("Sanctioned");
//            loanAppDTO.setTypeOfLoan("Business Loan");
//            loanAppDTO.setLoanAppDate(new Date());
//            loanAppDTO.setStatus("rejected");
//
//            when(modelMapper.map(Mockito.any(LoanApplication.class), Mockito.eq(LoanAppDTO.class))).thenReturn(loanAppDTO);

            LoanAppDTO actualLoanAppDTO=loanApplicationServiceImpl.getLoanApplicationByStatus("LOAN002");
            assertNotNull(actualLoanAppDTO);
        } catch(Exception e){
//            e.printStackTrace();
            assertTrue(true);
        }
    }

    @Test
    public void testGetAllLoanApplicationsByDatePositiveOneCustomerFound() {
        try {
            List<LoanApplication> loanApplicationList=mock(List.class);

            when(loanApplicationRepository.findByLoanAppDate(Mockito.any(Date.class))).thenReturn(loanApplicationList);
//            Iterable<CustomerMaster> iterableCustomerMasterMock=mock(Iterable.class);
//            when(customerMasterRepository.findAll()).thenReturn(iterableCustomerMasterMock);
            Iterator<LoanApplication> iteratorLoanApplicationMock =mock(Iterator.class);

            when(loanApplicationList.iterator()).thenReturn(iteratorLoanApplicationMock);
            when(iteratorLoanApplicationMock.hasNext()).thenReturn(true).thenReturn(false);

//            CustomerMaster customerMasterMock=mock(CustomerMaster.class);

            LoanApplication loanApplicationMock=mock(LoanApplication.class);
            when(iteratorLoanApplicationMock.next()).thenReturn(loanApplicationMock);

            CustomerMaster customerMasterMock=mock(CustomerMaster.class);
            when(loanApplicationMock.getCustomerMaster()).thenReturn(customerMasterMock);

            LoanAppDTO loanAppDTOMock=mock(LoanAppDTO.class);
            when(modelMapper.map(Mockito.any(LoanApplication.class), Mockito.eq(LoanAppDTO.class))).thenReturn(loanAppDTOMock);

            List<LoanAppDTO> loanAppDTOList =loanApplicationServiceImpl.getAllLoanApplicationsByDate(new Date(2024,10,18));

            assertTrue(loanAppDTOList.size()==1);
        }catch(Exception e) {
//            System.out.println(e);
            assertTrue(false);
        }
    }

    @Test
    public void testGetAllLoanApplicationsByDatePositiveMultipleCustomersFound() {
        try {
            List<LoanApplication> loanApplicationList=mock(List.class);

            when(loanApplicationRepository.findByLoanAppDate(Mockito.any(Date.class))).thenReturn(loanApplicationList);
//            Iterable<CustomerMaster> iterableCustomerMasterMock=mock(Iterable.class);
//            when(customerMasterRepository.findAll()).thenReturn(iterableCustomerMasterMock);
            Iterator<LoanApplication> iteratorLoanApplicationMock =mock(Iterator.class);

            when(loanApplicationList.iterator()).thenReturn(iteratorLoanApplicationMock);
            when(iteratorLoanApplicationMock.hasNext()).thenReturn(true).thenReturn(true).thenReturn(false);

//            CustomerMaster customerMasterMock=mock(CustomerMaster.class);

            LoanApplication loanApplicationMock=mock(LoanApplication.class);
            when(iteratorLoanApplicationMock.next()).thenReturn(loanApplicationMock);

            CustomerMaster customerMasterMock=mock(CustomerMaster.class);
            when(loanApplicationMock.getCustomerMaster()).thenReturn(customerMasterMock);

            LoanAppDTO loanAppDTOMock=mock(LoanAppDTO.class);
            when(modelMapper.map(Mockito.any(LoanApplication.class), Mockito.eq(LoanAppDTO.class))).thenReturn(loanAppDTOMock);

            List<LoanAppDTO> loanAppDTOList =loanApplicationServiceImpl.getAllLoanApplicationsByDate(new Date(2024,10,25));

            assertTrue(loanAppDTOList.size()>1);
        }catch(Exception e) {
            //	System.out.println(e);
            assertTrue(false);
        }
    }

    @Test
    public void testGetAllLoanApplicationsByDateException() {
        try {
            List<LoanApplication> loanApplicationList=mock(List.class);

            when(loanApplicationRepository.findByLoanAppDate(Mockito.any(Date.class))).thenReturn(loanApplicationList);
//            Iterable<CustomerMaster> iterableCustomerMasterMock=mock(Iterable.class);
//            when(customerMasterRepository.findAll()).thenReturn(iterableCustomerMasterMock);
            Iterator<LoanApplication> iteratorLoanApplicationMock =mock(Iterator.class);

            when(loanApplicationList.iterator()).thenReturn(iteratorLoanApplicationMock);
            when(iteratorLoanApplicationMock.hasNext()).thenReturn(false);

//            CustomerMaster customerMasterMock=mock(CustomerMaster.class);

            LoanApplication loanApplicationMock=mock(LoanApplication.class);
            when(iteratorLoanApplicationMock.next()).thenReturn(loanApplicationMock);

            CustomerMaster customerMasterMock=mock(CustomerMaster.class);
            when(loanApplicationMock.getCustomerMaster()).thenReturn(customerMasterMock);

            LoanAppDTO loanAppDTOMock=mock(LoanAppDTO.class);
            when(modelMapper.map(Mockito.any(LoanApplication.class), Mockito.eq(LoanAppDTO.class))).thenReturn(loanAppDTOMock);

            List<LoanAppDTO> loanAppDTOList =loanApplicationServiceImpl.getAllLoanApplicationsByDate(new Date(2024,10,31));

            assertTrue(!loanAppDTOList.isEmpty());
        }catch(Exception e) {
//            System.out.println(e);
            assertTrue(true);
        }
    }

    @Test
    public void TestUpdateLoanApplicationPositiveWhenStatusIsNewLoan() {
        try {
            LoanApplication loanApplication = new LoanApplication();
            loanApplication.setLoanAppId("LOAN001");
            loanApplication.setLoanAmt(200000);
            loanApplication.setNoOfYears(5);
            loanApplication.setPurpose("Home Renovation");
            loanApplication.setAppStatus("NewLoan");
            loanApplication.setTypeOfLoan("Home Loan");
            loanApplication.setLoanAppDate(new Date());
            loanApplication.setStatus("accepted");

            CustomerMaster customerMaster = new CustomerMaster();

            customerMaster.setCustId("CUST01");
            customerMaster.setCustFirstName("Adrineel");
            customerMaster.setCustLastName("Saha");
            customerMaster.setAddress("123 Street");
            customerMaster.setCity("Asansol");
            customerMaster.setContactNo(1234567890);
            customerMaster.setAdharCard(1456789012);
            customerMaster.setEmailId("adrineel.saha@cognizant.com");
            customerMaster.setBirthDate(new Date(2001, 10, 18));
            customerMaster.setMonthlySalary(65000);

            loanApplication.setCustomerMaster(customerMaster);

            Optional<LoanApplication> loanApplicationOptional = Optional.of(loanApplication);
            when(loanApplicationRepository.findById("LOAN001")).thenReturn(loanApplicationOptional);

            LoanAppDTO loanAppDTO = new LoanAppDTO();
            loanAppDTO.setLoanAppId("LOAN001");
            loanAppDTO.setCustId("CUST01");
            loanAppDTO.setLoanAmt(240000);
            loanAppDTO.setNoOfYears(8);
            loanAppDTO.setPurpose("Home Renovation");
            loanAppDTO.setAppStatus("NewLoan");
            loanAppDTO.setTypeOfLoan("Business Loan");
            loanAppDTO.setLoanAppDate(new Date());
            loanAppDTO.setStatus("accepted");

            LoanApplication updatedLoanApplication = new LoanApplication();
            updatedLoanApplication.setLoanAppId("LOAN001");
            updatedLoanApplication.setLoanAmt(240000);
            updatedLoanApplication.setNoOfYears(8);
            updatedLoanApplication.setPurpose("Home Renovation");
            updatedLoanApplication.setAppStatus("NewLoan");
            updatedLoanApplication.setTypeOfLoan("Business Loan");
            updatedLoanApplication.setLoanAppDate(new Date());
            updatedLoanApplication.setStatus("accepted");

            CustomerMaster updatedCustomerMaster = new CustomerMaster();

            updatedCustomerMaster.setCustId("CUST01");
            updatedCustomerMaster.setCustFirstName("Adrineel");
            updatedCustomerMaster.setCustLastName("Saha");
            updatedCustomerMaster.setAddress("123 Street");
            updatedCustomerMaster.setCity("Asansol");
            updatedCustomerMaster.setContactNo(1234567890);
            updatedCustomerMaster.setAdharCard(1456789012);
            updatedCustomerMaster.setEmailId("adrineel.saha@cognizant.com");
            updatedCustomerMaster.setBirthDate(new Date(2001, 10, 18));
            updatedCustomerMaster.setMonthlySalary(65000);

            loanApplication.setCustomerMaster(updatedCustomerMaster);

            when(loanApplicationRepository.save(Mockito.any())).thenReturn(updatedLoanApplication);
            when(modelMapper.map(Mockito.any(LoanApplication.class), Mockito.eq(LoanAppDTO.class))).thenReturn(loanAppDTO);

            LoanAppDTO actualLoanAppDTO = loanApplicationServiceImpl.updateLoanApplication("LOAN001", loanAppDTO);
            assertNotNull(actualLoanAppDTO);
        } catch (Exception e) {
//            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void TestUpdateLoanApplicationNegative() {
        try {
            LoanApplication loanApplication=new LoanApplication();
            loanApplication.setLoanAppId("LOAN002");
            loanApplication.setLoanAmt(150000);
            loanApplication.setNoOfYears(3);
            loanApplication.setPurpose("Car Purchase");
            loanApplication.setAppStatus("NewLoan");
            loanApplication.setTypeOfLoan("Auto Loan");
            loanApplication.setLoanAppDate(new Date());
            loanApplication.setStatus("no status");

            CustomerMaster customerMaster=new CustomerMaster();

            customerMaster.setCustId("CUST02");
            customerMaster.setCustFirstName("Arunabh");
            customerMaster.setCustLastName("Kalita");
            customerMaster.setAddress("456 Avenue");
            customerMaster.setCity("Dibrugarh");
            customerMaster.setContactNo(1876543210);
            customerMaster.setAdharCard(1567890123);
            customerMaster.setEmailId("arunabh.kalita@cognizant.com");
            customerMaster.setBirthDate(new Date(2000,5,15));
            customerMaster.setMonthlySalary(60000);

            loanApplication.setCustomerMaster(customerMaster);

            Optional<LoanApplication> loanApplicationOptional = Optional.of(loanApplication);
            when(loanApplicationRepository.findById("LOAN002")).thenReturn(loanApplicationOptional);

            LoanAppDTO loanAppDTO = new LoanAppDTO();
            loanAppDTO.setLoanAppId("LOAN002");
            loanAppDTO.setCustId("CUST02");
            loanAppDTO.setLoanAmt(150000);
            loanAppDTO.setNoOfYears(0);
            loanAppDTO.setPurpose("Car Purchase");
            loanAppDTO.setAppStatus("NewLoan");
            loanAppDTO.setTypeOfLoan("Auto Loan");
            loanAppDTO.setLoanAppDate(new Date());
            loanAppDTO.setStatus("accepted");

            LoanApplication updatedLoanApplication=new LoanApplication();
            updatedLoanApplication.setLoanAppId("LOAN002");
            updatedLoanApplication.setLoanAmt(150000);
            updatedLoanApplication.setNoOfYears(0);
            updatedLoanApplication.setPurpose("Car Purchase");
            updatedLoanApplication.setAppStatus("NewLoan");
            updatedLoanApplication.setTypeOfLoan("Auto Loan");
            updatedLoanApplication.setLoanAppDate(new Date());
            updatedLoanApplication.setStatus("accepted");

            CustomerMaster updatedcustomerMaster =new CustomerMaster();

            updatedcustomerMaster.setCustId("CUST02");
            updatedcustomerMaster.setCustFirstName("Arunabh");
            updatedcustomerMaster.setCustLastName("Kalita");
            updatedcustomerMaster.setAddress("456 Avenue");
            updatedcustomerMaster.setCity("Dibrugarh");
            updatedcustomerMaster.setContactNo(1876543210);
            updatedcustomerMaster.setAdharCard(1567890123);
            updatedcustomerMaster.setEmailId("arunabh.kalita@cognizant.com");
            updatedcustomerMaster.setBirthDate(new Date(2000,5,15));
            updatedcustomerMaster.setMonthlySalary(60000);

            loanApplication.setCustomerMaster(updatedcustomerMaster);

            when(loanApplicationRepository.save(Mockito.any())).thenReturn(updatedLoanApplication);
            when(modelMapper.map(Mockito.any(LoanApplication.class), Mockito.eq(LoanAppDTO.class))).thenReturn(loanAppDTO);

            LoanAppDTO actualLoanAppDTO = loanApplicationServiceImpl.updateLoanApplication("LOAN002", loanAppDTO);
            assertNotNull(actualLoanAppDTO);
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(true);
        }
    }

    @Test
    public void TestUpdateLoanApplicationPositiveWhenStatusIsApproved() {
        try {
            LoanApplication loanApplication=new LoanApplication();
            loanApplication.setLoanAppId("LOAN002");
            loanApplication.setLoanAmt(150000);
            loanApplication.setNoOfYears(3);
            loanApplication.setPurpose("Car Purchase");
            loanApplication.setAppStatus("Approved");
            loanApplication.setTypeOfLoan("Auto Loan");
            loanApplication.setLoanAppDate(new Date());
            loanApplication.setStatus("no status");

            CustomerMaster customerMaster=new CustomerMaster();

            customerMaster.setCustId("CUST02");
            customerMaster.setCustFirstName("Arunabh");
            customerMaster.setCustLastName("Kalita");
            customerMaster.setAddress("456 Avenue");
            customerMaster.setCity("Dibrugarh");
            customerMaster.setContactNo(1876543210);
            customerMaster.setAdharCard(1567890123);
            customerMaster.setEmailId("arunabh.kalita@cognizant.com");
            customerMaster.setBirthDate(new Date(2000,5,15));
            customerMaster.setMonthlySalary(60000);

            loanApplication.setCustomerMaster(customerMaster);

            Optional<LoanApplication> loanApplicationOptional = Optional.of(loanApplication);
            when(loanApplicationRepository.findById("LOAN002")).thenReturn(loanApplicationOptional);

            LoanAppDTO loanAppDTO = new LoanAppDTO();
            loanAppDTO.setLoanAppId("LOAN002");
            loanAppDTO.setCustId("CUST02");
            loanAppDTO.setLoanAmt(150000);
            loanAppDTO.setNoOfYears(3);
            loanAppDTO.setPurpose("Car Purchase");
            loanAppDTO.setAppStatus("Approved");
            loanAppDTO.setTypeOfLoan("Auto Loan");
            loanAppDTO.setLoanAppDate(new Date());
            loanAppDTO.setStatus("accepted");

            LoanApplication updatedLoanApplication=new LoanApplication();
            updatedLoanApplication.setLoanAppId("LOAN002");
            updatedLoanApplication.setLoanAmt(150000);
            updatedLoanApplication.setNoOfYears(3);
            updatedLoanApplication.setPurpose("Car Purchase");
            updatedLoanApplication.setAppStatus("Approved");
            updatedLoanApplication.setTypeOfLoan("Auto Loan");
            updatedLoanApplication.setLoanAppDate(new Date());
            updatedLoanApplication.setStatus("accepted");

            CustomerMaster updatedcustomerMaster =new CustomerMaster();

            updatedcustomerMaster.setCustId("CUST02");
            updatedcustomerMaster.setCustFirstName("Arunabh");
            updatedcustomerMaster.setCustLastName("Kalita");
            updatedcustomerMaster.setAddress("456 Avenue");
            updatedcustomerMaster.setCity("Dibrugarh");
            updatedcustomerMaster.setContactNo(1876543210);
            updatedcustomerMaster.setAdharCard(1567890123);
            updatedcustomerMaster.setEmailId("arunabh.kalita@cognizant.com");
            updatedcustomerMaster.setBirthDate(new Date(2000,5,15));
            updatedcustomerMaster.setMonthlySalary(60000);

            loanApplication.setCustomerMaster(updatedcustomerMaster);

            when(loanApplicationRepository.save(Mockito.any())).thenReturn(updatedLoanApplication);
            when(modelMapper.map(Mockito.any(LoanApplication.class), Mockito.eq(LoanAppDTO.class))).thenReturn(loanAppDTO);

            LoanAppDTO actualLoanAppDTO = loanApplicationServiceImpl.updateLoanApplication("LOAN002", loanAppDTO);
            assertNotNull(actualLoanAppDTO);
        } catch (Exception e) {
//            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void TestUpdateLoanApplicationLoanUnderProcessingException() {
        try {
            LoanApplication loanApplication=new LoanApplication();
            loanApplication.setLoanAppId("LOAN003");
            loanApplication.setLoanAmt(250000);
            loanApplication.setNoOfYears(7);
            loanApplication.setPurpose("Business Expansion");
            loanApplication.setAppStatus("Sanctioned");
            loanApplication.setTypeOfLoan("Business Loan");
            loanApplication.setLoanAppDate(new Date());
            loanApplication.setStatus("rejected");

            CustomerMaster customerMaster=new CustomerMaster();

            customerMaster.setCustId("CUST03");
            customerMaster.setCustFirstName("Yash");
            customerMaster.setCustLastName("Biswakarma");
            customerMaster.setAddress("789 Boulevard");
            customerMaster.setCity("Darjeeling");
            customerMaster.setContactNo(1122334455);
            customerMaster.setAdharCard(1456701234);
            customerMaster.setEmailId("yash.biswakarma@cognizant.com");
            customerMaster.setBirthDate(new Date(2001,9,29));
            customerMaster.setMonthlySalary(55000);

            loanApplication.setCustomerMaster(customerMaster);

            Optional<LoanApplication> loanApplicationOptional = Optional.of(loanApplication);
            when(loanApplicationRepository.findById("LOAN003")).thenReturn(loanApplicationOptional);

            LoanAppDTO loanAppDTO = new LoanAppDTO();
            loanAppDTO.setLoanAppId("LOAN003");
            loanAppDTO.setCustId("CUST03");
            loanAppDTO.setLoanAmt(280000);
            loanAppDTO.setNoOfYears(8);
            loanAppDTO.setPurpose("Business Expansion");
            loanAppDTO.setAppStatus("Sanctioned");
            loanAppDTO.setTypeOfLoan("Auto Loan");
            loanAppDTO.setLoanAppDate(new Date());
            loanAppDTO.setStatus("rejected");

            LoanApplication updatedLoanApplication=new LoanApplication();
            updatedLoanApplication.setLoanAppId("LOAN003");
            updatedLoanApplication.setLoanAmt(280000);
            updatedLoanApplication.setNoOfYears(8);
            updatedLoanApplication.setPurpose("Business Expansion");
            updatedLoanApplication.setAppStatus("Sanctioned");
            updatedLoanApplication.setTypeOfLoan("Auto Loan");
            updatedLoanApplication.setLoanAppDate(new Date());
            updatedLoanApplication.setStatus("rejected");

            CustomerMaster updatedcustomerMaster =new CustomerMaster();

            updatedcustomerMaster.setCustId("CUST03");
            updatedcustomerMaster.setCustFirstName("Yash");
            updatedcustomerMaster.setCustLastName("Biswakarma");
            updatedcustomerMaster.setAddress("789 Boulevard");
            updatedcustomerMaster.setCity("Darjeeling");
            updatedcustomerMaster.setContactNo(1122334455);
            updatedcustomerMaster.setAdharCard(1456701234);
            updatedcustomerMaster.setEmailId("yash.biswakarma@cognizant.com");
            updatedcustomerMaster.setBirthDate(new Date(2001,9,29));
            updatedcustomerMaster.setMonthlySalary(55000);

            loanApplication.setCustomerMaster(updatedcustomerMaster);

            when(loanApplicationRepository.save(Mockito.any())).thenReturn(updatedLoanApplication);
            when(modelMapper.map(Mockito.any(LoanApplication.class), Mockito.eq(LoanAppDTO.class))).thenReturn(loanAppDTO);

            LoanAppDTO actualLoanAppDTO = loanApplicationServiceImpl.updateLoanApplication("LOAN003", loanAppDTO);
            assertNotNull(actualLoanAppDTO);
        } catch (Exception e) {
//            e.printStackTrace();
            assertTrue(true);
        }
    }

    @Test
    public void testAddLoanApplicationPositive() {
        try {
            LoanAppDTO loanAppDTO = new LoanAppDTO();
            loanAppDTO.setLoanAppId("LOAN001");
            loanAppDTO.setCustId("CUST01");
            loanAppDTO.setLoanAmt(200000);
            loanAppDTO.setNoOfYears(5);
            loanAppDTO.setPurpose("Home Renovation");
            loanAppDTO.setAppStatus("NewLoan");
            loanAppDTO.setTypeOfLoan("Home Loan");
            loanAppDTO.setLoanAppDate(new Date());
            loanAppDTO.setStatus("accepted");

            CustomerMaster customerMaster = new CustomerMaster();

            customerMaster.setCustId("CUST01");
            customerMaster.setCustFirstName("Adrineel");
            customerMaster.setCustLastName("Saha");
            customerMaster.setAddress("123 Street");
            customerMaster.setCity("Asansol");
            customerMaster.setContactNo(1234567890);
            customerMaster.setAdharCard(1456789012);
            customerMaster.setEmailId("adrineel.saha@cognizant.com");
            customerMaster.setBirthDate(new Date(2001, 10, 18));
            customerMaster.setMonthlySalary(65000);

            when(customerMasterRepository.findById(Mockito.anyString())).thenReturn(Optional.of(customerMaster));

            LoanApplication loanApplication=new LoanApplication();
            loanApplication.setLoanAppId("LOAN001");
            loanApplication.setLoanAmt(200000);
            loanApplication.setNoOfYears(5);
            loanApplication.setPurpose("Home Renovation");
            loanApplication.setAppStatus("NewLoan");
            loanApplication.setTypeOfLoan("Home Loan");
            loanApplication.setLoanAppDate(new Date());
            loanApplication.setStatus("accepted");
            loanApplication.setCustomerMaster(customerMaster);

            when(modelMapper.map(Mockito.any(LoanAppDTO.class),Mockito.eq(LoanApplication.class))).thenReturn(loanApplication);
            when(loanApplicationRepository.save(Mockito.any())).thenReturn(loanApplication);
            when(modelMapper.map(Mockito.any(LoanApplication.class),Mockito.eq(LoanAppDTO.class))).thenReturn(loanAppDTO);

            LoanAppDTO actualLoanAppDTO=loanApplicationServiceImpl.addLoanApplication(loanAppDTO);
            assertNotNull(actualLoanAppDTO);
        }catch(Exception e) {
            //e.printStackTrace();
            //	System.out.println(e);
            assertTrue(false);
        }
    }

    @Test
    public void testAddLoanApplicationNegative() {
        try {
            LoanAppDTO loanAppDTO = new LoanAppDTO();
            loanAppDTO.setLoanAppId("LOAN001");
            loanAppDTO.setCustId("CUST01");
            loanAppDTO.setLoanAmt(200000);
            loanAppDTO.setNoOfYears(5);
            loanAppDTO.setPurpose("Home Renovation");
            loanAppDTO.setAppStatus("NewLoanApproved");
            loanAppDTO.setTypeOfLoan("Home Loan");
            loanAppDTO.setLoanAppDate(new Date(2024,10,8));
            loanAppDTO.setStatus("acceptedrejected");

            CustomerMaster customerMaster = new CustomerMaster();

            customerMaster.setCustId("CUST01");
            customerMaster.setCustFirstName("Adrineel");
            customerMaster.setCustLastName("Saha");
            customerMaster.setAddress("123 Street");
            customerMaster.setCity("Asansol");
            customerMaster.setContactNo(1234567890);
            customerMaster.setAdharCard(1456789012);
            customerMaster.setEmailId("adrineel.saha@cognizant.com");
            customerMaster.setBirthDate(new Date(2001, 10, 18));
            customerMaster.setMonthlySalary(65000);

            when(customerMasterRepository.findById(Mockito.anyString())).thenReturn(Optional.of(customerMaster));

            LoanApplication loanApplication=new LoanApplication();
            loanApplication.setLoanAppId("LOAN001");
            loanApplication.setLoanAmt(200000);
            loanApplication.setNoOfYears(5);
            loanApplication.setPurpose("Home Renovation");
            loanApplication.setAppStatus("NewLoanApproved");
            loanApplication.setTypeOfLoan("Home Loan");
            loanApplication.setLoanAppDate(new Date(2024,10,8));
            loanApplication.setStatus("acceptedrejected");
            loanApplication.setCustomerMaster(customerMaster);

            when(modelMapper.map(Mockito.any(LoanAppDTO.class),Mockito.eq(LoanApplication.class))).thenReturn(loanApplication);
            when(loanApplicationRepository.save(Mockito.any())).thenReturn(loanApplication);
            when(modelMapper.map(Mockito.any(LoanApplication.class),Mockito.eq(LoanAppDTO.class))).thenReturn(loanAppDTO);

            LoanAppDTO actualLoanAppDTO=loanApplicationServiceImpl.addLoanApplication(loanAppDTO);
            assertNotNull(actualLoanAppDTO);
        }catch(Exception e) {
//            e.printStackTrace();
            //	System.out.println(e);
            assertTrue(true);
        }
    }

    @Test
    public void testAddLoanApplicationException() {
        try {
            LoanAppDTO loanAppDTO = new LoanAppDTO();
            loanAppDTO.setLoanAppId("LOAN001");
            loanAppDTO.setCustId("CUST01");
            loanAppDTO.setLoanAmt(0);
            loanAppDTO.setNoOfYears(5);
            loanAppDTO.setPurpose("Home Renovation");
            loanAppDTO.setAppStatus("NewLoan");
            loanAppDTO.setTypeOfLoan("Home Loan");
            loanAppDTO.setLoanAppDate(new Date());
            loanAppDTO.setStatus("accepted");

            CustomerMaster customerMaster = new CustomerMaster();

            customerMaster.setCustId("CUST01");
            customerMaster.setCustFirstName("Adrineel");
            customerMaster.setCustLastName("Saha");
            customerMaster.setAddress("123 Street");
            customerMaster.setCity("Asansol");
            customerMaster.setContactNo(1234567890);
            customerMaster.setAdharCard(1456789012);
            customerMaster.setEmailId("adrineel.saha@cognizant.com");
            customerMaster.setBirthDate(new Date(2001, 10, 18));
            customerMaster.setMonthlySalary(65000);

            when(customerMasterRepository.findById(Mockito.anyString())).thenReturn(Optional.of(customerMaster));

            LoanApplication loanApplication=new LoanApplication();
            loanApplication.setLoanAppId("LOAN001");
            loanApplication.setLoanAmt(0);
            loanApplication.setNoOfYears(5);
            loanApplication.setPurpose("Home Renovation");
            loanApplication.setAppStatus("NewLoan");
            loanApplication.setTypeOfLoan("Home Loan");
            loanApplication.setLoanAppDate(new Date());
            loanApplication.setStatus("accepted");
            loanApplication.setCustomerMaster(customerMaster);

            when(modelMapper.map(Mockito.any(LoanAppDTO.class),Mockito.eq(LoanApplication.class))).thenReturn(loanApplication);
            when(loanApplicationRepository.save(Mockito.any())).thenReturn(loanApplication);
            when(modelMapper.map(Mockito.any(LoanApplication.class),Mockito.eq(LoanAppDTO.class))).thenReturn(loanAppDTO);

            LoanAppDTO actualLoanAppDTO=loanApplicationServiceImpl.addLoanApplication(loanAppDTO);
            assertNotNull(actualLoanAppDTO);
        }catch(Exception e) {
//            e.printStackTrace();
            //	System.out.println(e);
            assertTrue(true);
        }
    }

}
