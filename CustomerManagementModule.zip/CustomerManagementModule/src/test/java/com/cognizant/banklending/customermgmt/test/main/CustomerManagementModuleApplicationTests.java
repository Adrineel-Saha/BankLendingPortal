package com.cognizant.banklending.customermgmt.test.main;

import com.cognizant.banklending.customermgmt.controllers.CustomerManagementController;
import com.cognizant.banklending.customermgmt.main.CustomerManagementModuleApplication;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest(classes= CustomerManagementModuleApplication.class)
class CustomerManagementModuleApplicationTests {
	@Autowired
	private CustomerManagementController customerManagementController;

	@Test
	void contextLoads() {
		assertNotNull(customerManagementController);
	}

}
