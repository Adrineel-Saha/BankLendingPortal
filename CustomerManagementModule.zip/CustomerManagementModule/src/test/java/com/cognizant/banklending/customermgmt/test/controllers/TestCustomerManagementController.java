package com.cognizant.banklending.customermgmt.test.controllers;

import com.cognizant.banklending.customermgmt.controllers.CustomerManagementController;
import com.cognizant.banklending.customermgmt.dtos.CustomerDTO;
import com.cognizant.banklending.customermgmt.dtos.LoanAppDTO;
import com.cognizant.banklending.customermgmt.dtos.ReducedPaymentDTO;
import com.cognizant.banklending.customermgmt.main.CustomerManagementModuleApplication;
import com.cognizant.banklending.customermgmt.services.CustomerMasterService;
import com.cognizant.banklending.customermgmt.services.LoanApplicationService;
import com.cognizant.banklending.customermgmt.services.ReducedPaymentService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@SpringBootTest(classes= CustomerManagementModuleApplication.class)
public class TestCustomerManagementController {
    @Mock
    private CustomerMasterService customerMasterService;

    @Mock
    private LoanApplicationService loanApplicationService;

    @Mock
    private ReducedPaymentService reducedPaymentService;

    @InjectMocks
    private CustomerManagementController customerManagementController;

    @Autowired
    private LocalValidatorFactoryBean validator;

    @BeforeEach
    void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
    }

    @AfterEach
    void tearDown() throws Exception {

    }

    @Test
    public void testGetAllCustomersPositiveAssertReturnValue() {
        List<CustomerDTO> customerDTOList=new ArrayList<>();

        CustomerDTO customerDTO=new CustomerDTO();
        customerDTO.setCustId("CUST01");
        customerDTO.setCustFirstName("Adrineel");
        customerDTO.setCustLastName("Saha");
        customerDTO.setAddress("123 Street");
        customerDTO.setCity("Asansol");
        customerDTO.setContactNo(1234567890);
        customerDTO.setAdharCard(1456789012);
        customerDTO.setEmailId("adrineel.saha@cognizant.com");
        customerDTO.setBirthDate(new Date(2001,10,18));
        customerDTO.setMonthlySalary(65000);

        customerDTOList.add(customerDTO);

        try {
            when(customerMasterService.getAllCustomers()).thenReturn(customerDTOList);
            ResponseEntity<List<CustomerDTO>> responseEntity=customerManagementController.getAllCustomers();
            List<CustomerDTO> actualCustomerDTOList=responseEntity.getBody();
            assertTrue(actualCustomerDTOList.size()>0);
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testGetAllCustomersPositiveAssertStatusCode() {
        List<CustomerDTO> customerDTOList=new ArrayList<>();

        CustomerDTO customerDTO=new CustomerDTO();
        customerDTO.setCustId("CUST01");
        customerDTO.setCustFirstName("Adrineel");
        customerDTO.setCustLastName("Saha");
        customerDTO.setAddress("123 Street");
        customerDTO.setCity("Asansol");
        customerDTO.setContactNo(1234567890);
        customerDTO.setAdharCard(1456789012);
        customerDTO.setEmailId("adrineel.saha@cognizant.com");
        customerDTO.setBirthDate(new Date(2001,10,18));
        customerDTO.setMonthlySalary(65000);

        customerDTOList.add(customerDTO);

        try {
            when(customerMasterService.getAllCustomers()).thenReturn(customerDTOList);
            ResponseEntity<List<CustomerDTO>> responseEntity=customerManagementController.getAllCustomers();
            assertEquals(200,responseEntity.getStatusCodeValue());
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testGetAllCustomersNegativeAssertReturnValue() {
        List<CustomerDTO> customerDTOList=new ArrayList<>();
        try {
            when(customerMasterService.getAllCustomers()).thenReturn(customerDTOList);
            ResponseEntity<List<CustomerDTO>> responseEntity=customerManagementController.getAllCustomers();
            assertNull(responseEntity.getBody());
        }catch(Exception e) {
//            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void testGetAllCustomersNegativeAssertStatusCode() {
        List<CustomerDTO> customerDTOList=new ArrayList<>();
        try {
            when(customerMasterService.getAllCustomers()).thenReturn(customerDTOList);
            ResponseEntity<List<CustomerDTO>> responseEntity=customerManagementController.getAllCustomers();
            assertEquals(400,responseEntity.getStatusCodeValue());
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testGetCustomerByIdPositiveAssertReturnValue() {
        CustomerDTO customerDTO=new CustomerDTO();
        customerDTO.setCustId("CUST01");
        customerDTO.setCustFirstName("Adrineel");
        customerDTO.setCustLastName("Saha");
        customerDTO.setAddress("123 Street");
        customerDTO.setCity("Asansol");
        customerDTO.setContactNo(1234567890);
        customerDTO.setAdharCard(1456789012);
        customerDTO.setEmailId("adrineel.saha@cognizant.com");
        customerDTO.setBirthDate(new Date(2001,10,18));
        customerDTO.setMonthlySalary(65000);

        try {
            when(customerMasterService.getCustomerById(Mockito.anyString())).thenReturn(customerDTO);
            ResponseEntity<CustomerDTO> responseEntity=customerManagementController.getCustomerById("CUST01");
            CustomerDTO actualCustomerDTO=responseEntity.getBody();
            assertNotNull(actualCustomerDTO);
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testGetCustomerByIdPositiveAssertStatusCode() {
        CustomerDTO customerDTO=new CustomerDTO();
        customerDTO.setCustId("CUST01");
        customerDTO.setCustFirstName("Adrineel");
        customerDTO.setCustLastName("Saha");
        customerDTO.setAddress("123 Street");
        customerDTO.setCity("Asansol");
        customerDTO.setContactNo(1234567890);
        customerDTO.setAdharCard(1456789012);
        customerDTO.setEmailId("adrineel.saha@cognizant.com");
        customerDTO.setBirthDate(new Date(2001,10,18));
        customerDTO.setMonthlySalary(65000);

        try {
            when(customerMasterService.getCustomerById(Mockito.anyString())).thenReturn(customerDTO);
            ResponseEntity<CustomerDTO> responseEntity=customerManagementController.getCustomerById("CUST01");
            assertEquals(200,responseEntity.getStatusCodeValue());
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testGetCustomerByIdNegativeAssertReturnValue() {
        CustomerDTO customerDTO=null;
        try {
            when(customerMasterService.getCustomerById(Mockito.anyString())).thenReturn(customerDTO);
            ResponseEntity<CustomerDTO> responseEntity=customerManagementController.getCustomerById("CUST01");
            CustomerDTO actualCustomerDTO=responseEntity.getBody();
            assertNull(actualCustomerDTO);
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testGetCustomerByIdNegativeAssertStatusCode() {
        CustomerDTO customerDTO=null;
        try {
            when(customerMasterService.getCustomerById(Mockito.anyString())).thenReturn(customerDTO);
            ResponseEntity<CustomerDTO> responseEntity=customerManagementController.getCustomerById("CUST01");
            assertEquals(400,responseEntity.getStatusCodeValue());
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testGetAllCustomersByStatusPositiveAssertReturnValue() {
        List<CustomerDTO> customerDTOList=new ArrayList<>();

        CustomerDTO customerDTO=new CustomerDTO();
        customerDTO.setCustId("CUST02");
        customerDTO.setCustFirstName("Arunabh");
        customerDTO.setCustLastName("Kalita");
        customerDTO.setAddress("456 Avenue");
        customerDTO.setCity("Dibrugarh");
        customerDTO.setContactNo(1876543210);
        customerDTO.setAdharCard(1456701234);
        customerDTO.setEmailId("arunabh.kalita@cognizant.com");
        customerDTO.setBirthDate(new Date(2000,6,15));
        customerDTO.setMonthlySalary(60000);

        customerDTOList.add(customerDTO);

        try {
            when(customerMasterService.getAllCustomersByStatus(Mockito.anyString())).thenReturn(customerDTOList);
            ResponseEntity<List<CustomerDTO>> responseEntity=customerManagementController.getAllCustomersByStatus("Approved");
            List<CustomerDTO> actualCustomerDTOList=responseEntity.getBody();
            assertTrue(actualCustomerDTOList.size()>0);
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testGetAllCustomersByStatusPositiveAssertStatusCode() {
        List<CustomerDTO> customerDTOList=new ArrayList<>();

        CustomerDTO customerDTO=new CustomerDTO();
        customerDTO.setCustId("CUST02");
        customerDTO.setCustFirstName("Arunabh");
        customerDTO.setCustLastName("Kalita");
        customerDTO.setAddress("456 Avenue");
        customerDTO.setCity("Dibrugarh");
        customerDTO.setContactNo(1876543210);
        customerDTO.setAdharCard(1456701234);
        customerDTO.setEmailId("arunabh.kalita@cognizant.com");
        customerDTO.setBirthDate(new Date(2000,6,15));
        customerDTO.setMonthlySalary(60000);

        customerDTOList.add(customerDTO);

        try {
            when(customerMasterService.getAllCustomersByStatus(Mockito.anyString())).thenReturn(customerDTOList);
            ResponseEntity<List<CustomerDTO>> responseEntity=customerManagementController.getAllCustomersByStatus("Approved");
            assertEquals(200,responseEntity.getStatusCodeValue());
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testGetAllCustomersByStatusNegativeAssertReturnValue() {
        List<CustomerDTO> customerDTOList=new ArrayList<>();
        try {
            when(customerMasterService.getAllCustomersByStatus(Mockito.anyString())).thenReturn(customerDTOList);
            ResponseEntity<List<CustomerDTO>> responseEntity=customerManagementController.getAllCustomersByStatus("Approved");
            assertNull(responseEntity.getBody());
        }catch(Exception e) {
//            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void testGetAllCustomersByStatusNegativeAssertStatusCode() {
        List<CustomerDTO> customerDTOList=new ArrayList<>();
        try {
            when(customerMasterService.getAllCustomersByStatus(Mockito.anyString())).thenReturn(customerDTOList);
            ResponseEntity<List<CustomerDTO>> responseEntity=customerManagementController.getAllCustomersByStatus("Approved");
            assertEquals(400,responseEntity.getStatusCodeValue());
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testAddCustomerWhenCustomerIsValid() {
        CustomerDTO customerDTO=new CustomerDTO();
        customerDTO.setCustId("CUST02");
        customerDTO.setCustFirstName("Ankush");
        customerDTO.setCustLastName("Samanta");
        customerDTO.setAddress("456 Street");
        customerDTO.setCity("Bardhaman");
        customerDTO.setContactNo(1676543210);
        customerDTO.setAdharCard(1467891123);
        customerDTO.setEmailId("ankush.samanta@cognizant.com");
        customerDTO.setBirthDate(new Date(2001,8,10));
        customerDTO.setMonthlySalary(50000);

        validator.validate(customerDTO).stream().forEach((constraintViolation)->assertNull(constraintViolation));
    }

    @Test
    public void testAddCustomerPositiveAssertReturnvalue() {
        CustomerDTO customerDTO=new CustomerDTO();
        customerDTO.setCustId("CUST02");
        customerDTO.setCustFirstName("Ankush");
        customerDTO.setCustLastName("Samanta");
        customerDTO.setAddress("456 Street");
        customerDTO.setCity("Bardhaman");
        customerDTO.setContactNo(1676543210);
        customerDTO.setAdharCard(1467891123);
        customerDTO.setEmailId("ankush.samanta@cognizant.com");
        customerDTO.setBirthDate(new Date(2001,8,10));
        customerDTO.setMonthlySalary(50000);

        try {
            when(customerMasterService.addCustomer(Mockito.any())).thenReturn(customerDTO);
            ResponseEntity<CustomerDTO> responseEntity=customerManagementController.addCustomer(customerDTO);
            CustomerDTO actualCustomerDTO=responseEntity.getBody();
            assertNotNull(actualCustomerDTO);
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testAddCustomerPositiveAssertStatusCode() {
        CustomerDTO customerDTO=new CustomerDTO();
        customerDTO.setCustId("CUST02");
        customerDTO.setCustFirstName("Ankush");
        customerDTO.setCustLastName("Samanta");
        customerDTO.setAddress("456 Street");
        customerDTO.setCity("Bardhaman");
        customerDTO.setContactNo(1676543210);
        customerDTO.setAdharCard(1467891123);
        customerDTO.setEmailId("ankush.samanta@cognizant.com");
        customerDTO.setBirthDate(new Date(2001,8,10));
        customerDTO.setMonthlySalary(50000);

        try {
            when(customerMasterService.addCustomer(Mockito.any())).thenReturn(customerDTO);
            ResponseEntity<CustomerDTO> responseEntity=customerManagementController.addCustomer(customerDTO);
            assertEquals(201,responseEntity.getStatusCodeValue());
        }catch(Exception e) {
//            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void testAddCustomerWhenCustomerIsNotValid() {
        CustomerDTO customerDTO=new CustomerDTO();
        customerDTO.setCustId("CUST02");
        customerDTO.setCustFirstName("An");
        customerDTO.setCustLastName("Sa");
        customerDTO.setAddress("456 Street");
        customerDTO.setCity("Bardhaman");
        customerDTO.setContactNo(167654321);
        customerDTO.setAdharCard(1467891123);
        customerDTO.setEmailId("ankush.samanta@gmail.com");
        customerDTO.setBirthDate(new Date(2010,8,10));
        customerDTO.setMonthlySalary(50000);

        validator.validate(customerDTO).stream().forEach((constraintViolation)->assertNotNull(constraintViolation));
    }

    @Test
    public void testAddCustomerNegativeAssertReturnvalue() {
        CustomerDTO customerDTO=null;

        try {
            when(customerMasterService.addCustomer(Mockito.any())).thenReturn(customerDTO);
            ResponseEntity<CustomerDTO> responseEntity=customerManagementController.addCustomer(customerDTO);
            CustomerDTO actualCustomerDTO=responseEntity.getBody();
            assertNull(actualCustomerDTO);
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testAddCustomerNegativeAssertStatusCode() {
        CustomerDTO customerDTO=null;

        try {
            when(customerMasterService.addCustomer(Mockito.any())).thenReturn(customerDTO);
            ResponseEntity<CustomerDTO> responseEntity=customerManagementController.addCustomer(customerDTO);
            assertEquals(400,responseEntity.getStatusCodeValue());
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testUpdateCustomerWhenCustomerIsValid() {
        CustomerDTO customerDTO=new CustomerDTO();
        customerDTO.setCustId("CUST02");
        customerDTO.setCustFirstName("Akash");
        customerDTO.setCustLastName("Banerjee");
        customerDTO.setAddress("546 Avenue");
        customerDTO.setCity("Asansol");
        customerDTO.setContactNo(1776543210);
        customerDTO.setAdharCard(1567891123);
        customerDTO.setEmailId("akash.banerjee@cognizant.com");
        customerDTO.setBirthDate(new Date(2001,5,15));
        customerDTO.setMonthlySalary(55000);

        validator.validate(customerDTO).stream().forEach((constraintViolation)->assertNull(constraintViolation));
    }

    @Test
    public void testUpdateCustomerPositiveAssertReturnvalue() {
        CustomerDTO customerDTO=new CustomerDTO();
        customerDTO.setCustId("CUST02");
        customerDTO.setCustFirstName("Akash");
        customerDTO.setCustLastName("Banerjee");
        customerDTO.setAddress("546 Avenue");
        customerDTO.setCity("Asansol");
        customerDTO.setContactNo(1776543210);
        customerDTO.setAdharCard(1567891123);
        customerDTO.setEmailId("akash.banerjee@cognizant.com");
        customerDTO.setBirthDate(new Date(2001,5,15));
        customerDTO.setMonthlySalary(55000);

        try {
            when(customerMasterService.updateCustomer(Mockito.anyString(),Mockito.any())).thenReturn(customerDTO);
            ResponseEntity<CustomerDTO> responseEntity=customerManagementController.updateCustomer("CUST02",customerDTO);
            CustomerDTO actualCustomerDTO=responseEntity.getBody();
            assertNotNull(actualCustomerDTO);
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testUpdateCustomerPositiveAssertStatusCode() {
        CustomerDTO customerDTO=new CustomerDTO();
        customerDTO.setCustId("CUST02");
        customerDTO.setCustFirstName("Akash");
        customerDTO.setCustLastName("Banerjee");
        customerDTO.setAddress("546 Avenue");
        customerDTO.setCity("Asansol");
        customerDTO.setContactNo(1776543210);
        customerDTO.setAdharCard(1567891123);
        customerDTO.setEmailId("akash.banerjee@cognizant.com");
        customerDTO.setBirthDate(new Date(2001,5,15));
        customerDTO.setMonthlySalary(55000);

        try {
            when(customerMasterService.updateCustomer(Mockito.anyString(),Mockito.any())).thenReturn(customerDTO);
            ResponseEntity<CustomerDTO> responseEntity=customerManagementController.updateCustomer("CUST02",customerDTO);
            assertEquals(202,responseEntity.getStatusCodeValue());
        }catch(Exception e) {
//            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void testUpdateCustomerWhenCustomerIsNotValid() {
        CustomerDTO customerDTO=new CustomerDTO();
        customerDTO.setCustId("CUST02");
        customerDTO.setCustFirstName("Ak");
        customerDTO.setCustLastName("Ba");
        customerDTO.setAddress("546 Avenue");
        customerDTO.setCity("Asansol");
        customerDTO.setContactNo(177654320);
        customerDTO.setAdharCard(1567891123);
        customerDTO.setEmailId("akash.banerjee@gmail.com");
        customerDTO.setBirthDate(new Date(2010,5,15));
        customerDTO.setMonthlySalary(55000);

        validator.validate(customerDTO).stream().forEach((constraintViolation)->assertNotNull(constraintViolation));
    }

    @Test
    public void testUpdateCustomerNegativeAssertReturnvalue() {
        CustomerDTO customerDTO=null;

        try {
            when(customerMasterService.updateCustomer(Mockito.anyString(),Mockito.any())).thenReturn(customerDTO);
            ResponseEntity<CustomerDTO> responseEntity=customerManagementController.updateCustomer("CUST02",customerDTO);
            CustomerDTO actualCustomerDTO=responseEntity.getBody();
            assertNull(actualCustomerDTO);
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testUpdateCustomerNegativeAssertStatusCode() {
        CustomerDTO customerDTO=null;

        try {
            when(customerMasterService.updateCustomer(Mockito.anyString(),Mockito.any())).thenReturn(customerDTO);
            ResponseEntity<CustomerDTO> responseEntity=customerManagementController.updateCustomer("CUST02",customerDTO);
            assertEquals(400,responseEntity.getStatusCodeValue());
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testGetLoanApplicationByIdPositiveAssertReturnValue() {
        LoanAppDTO loanAppDTO=new LoanAppDTO();
        loanAppDTO.setLoanAppId("LOAN001");
        loanAppDTO.setCustId("CUST01");
        loanAppDTO.setLoanAmt(200000);
        loanAppDTO.setNoOfYears(5);
        loanAppDTO.setPurpose("Home Renovation");
        loanAppDTO.setAppStatus("NewLoan");
        loanAppDTO.setTypeOfLoan("Home Loan");
        loanAppDTO.setLoanAppDate(new Date());
        loanAppDTO.setStatus("accepted");

        try {
            when(loanApplicationService.getLoanApplicationById(Mockito.anyString())).thenReturn(loanAppDTO);
            ResponseEntity<LoanAppDTO> responseEntity=customerManagementController.getLoanApplicationById("LOAN001");
            LoanAppDTO actualloanAppDTO=responseEntity.getBody();
            assertNotNull(actualloanAppDTO);
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testGetLoanApplicationByIdPositiveAssertStatusCode() {
        LoanAppDTO loanAppDTO=new LoanAppDTO();
        loanAppDTO.setLoanAppId("LOAN001");
        loanAppDTO.setCustId("CUST01");
        loanAppDTO.setLoanAmt(200000);
        loanAppDTO.setNoOfYears(5);
        loanAppDTO.setPurpose("Home Renovation");
        loanAppDTO.setAppStatus("NewLoan");
        loanAppDTO.setTypeOfLoan("Home Loan");
        loanAppDTO.setLoanAppDate(new Date());
        loanAppDTO.setStatus("accepted");

        try {
            when(loanApplicationService.getLoanApplicationById(Mockito.anyString())).thenReturn(loanAppDTO);
            ResponseEntity<LoanAppDTO> responseEntity=customerManagementController.getLoanApplicationById("LOAN001");
            assertEquals(200,responseEntity.getStatusCodeValue());
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testGetLoanApplicationByIdNegativeAssertReturnValue() {
        LoanAppDTO loanAppDTO=null;
        try {
            when(loanApplicationService.getLoanApplicationById(Mockito.anyString())).thenReturn(loanAppDTO);
            ResponseEntity<LoanAppDTO> responseEntity=customerManagementController.getLoanApplicationById("LOAN001");
            LoanAppDTO actualloanAppDTO=responseEntity.getBody();
            assertNull(actualloanAppDTO);
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testGetLoanApplicationByIdNegativeAssertStatusCode() {
        LoanAppDTO loanAppDTO=null;
        try {
            when(loanApplicationService.getLoanApplicationById(Mockito.anyString())).thenReturn(loanAppDTO);
            ResponseEntity<LoanAppDTO> responseEntity=customerManagementController.getLoanApplicationById("LOAN001");
            assertEquals(400,responseEntity.getStatusCodeValue());
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testGetLoanApplicationByStatusPositiveAssertReturnValue() {
        LoanAppDTO loanAppDTO=new LoanAppDTO();
        loanAppDTO.setLoanAppId("LOAN003");
        loanAppDTO.setCustId("CUST03");
        loanAppDTO.setLoanAmt(250000);
        loanAppDTO.setNoOfYears(7);
        loanAppDTO.setPurpose("Business Expansion");
        loanAppDTO.setAppStatus("Sanctioned");
        loanAppDTO.setTypeOfLoan("Business Loan");
        loanAppDTO.setLoanAppDate(new Date());
        loanAppDTO.setStatus("rejected");

        try {
            when(loanApplicationService.getLoanApplicationByStatus(Mockito.anyString())).thenReturn(loanAppDTO);
            ResponseEntity<LoanAppDTO> responseEntity=customerManagementController.getLoanApplicationByStatus("LOAN003");
            LoanAppDTO actualloanAppDTO=responseEntity.getBody();
            assertNotNull(actualloanAppDTO);
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testGetLoanApplicationByStatusPositiveAssertStatusCode() {
        LoanAppDTO loanAppDTO=new LoanAppDTO();
        loanAppDTO.setLoanAppId("LOAN003");
        loanAppDTO.setCustId("CUST03");
        loanAppDTO.setLoanAmt(250000);
        loanAppDTO.setNoOfYears(7);
        loanAppDTO.setPurpose("Business Expansion");
        loanAppDTO.setAppStatus("Sanctioned");
        loanAppDTO.setTypeOfLoan("Business Loan");
        loanAppDTO.setLoanAppDate(new Date());
        loanAppDTO.setStatus("rejected");

        try {
            when(loanApplicationService.getLoanApplicationByStatus(Mockito.anyString())).thenReturn(loanAppDTO);
            ResponseEntity<LoanAppDTO> responseEntity=customerManagementController.getLoanApplicationByStatus("LOAN001");
            assertEquals(200,responseEntity.getStatusCodeValue());
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testGetLoanApplicationByStatusNegativeAssertReturnValue() {
        LoanAppDTO loanAppDTO=null;
        try {
            when(loanApplicationService.getLoanApplicationByStatus(Mockito.anyString())).thenReturn(loanAppDTO);
            ResponseEntity<LoanAppDTO> responseEntity=customerManagementController.getLoanApplicationByStatus("LOAN001");
            LoanAppDTO actualloanAppDTO=responseEntity.getBody();
            assertNull(actualloanAppDTO);
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testGetLoanApplicationByStatusNegativeAssertStatusCode() {
        LoanAppDTO loanAppDTO=null;
        try {
            when(loanApplicationService.getLoanApplicationByStatus(Mockito.anyString())).thenReturn(loanAppDTO);
            ResponseEntity<LoanAppDTO> responseEntity=customerManagementController.getLoanApplicationByStatus("LOAN001");
            assertEquals(400,responseEntity.getStatusCodeValue());
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testGetAllLoanApplicationsByDatePositiveAssertReturnValue() {
        List<LoanAppDTO> loanAppDTOList=new ArrayList<>();

        LoanAppDTO loanAppDTO=new LoanAppDTO();
        loanAppDTO.setLoanAppId("LOAN002");
        loanAppDTO.setCustId("CUST002");
        loanAppDTO.setLoanAmt(150000);
        loanAppDTO.setNoOfYears(3);
        loanAppDTO.setPurpose("Car Purchase");
        loanAppDTO.setAppStatus("Approved");
        loanAppDTO.setTypeOfLoan("Auto Loan");
        loanAppDTO.setLoanAppDate(new Date());
        loanAppDTO.setStatus("no status");

        loanAppDTOList.add(loanAppDTO);

        try {
            when(loanApplicationService.getAllLoanApplicationsByDate(Mockito.any(Date.class))).thenReturn(loanAppDTOList);
            ResponseEntity<List<LoanAppDTO>> responseEntity=customerManagementController.getAllLoanApplicationsByDate(new Date());
            List<LoanAppDTO> actualLoanAppDTOList=responseEntity.getBody();
            assertTrue(actualLoanAppDTOList.size()>0);
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testGetAllLoanApplicationsByDatePositiveAssertStatusCode() {
        List<LoanAppDTO> loanAppDTOList=new ArrayList<>();

        LoanAppDTO loanAppDTO=new LoanAppDTO();
        loanAppDTO.setLoanAppId("LOAN002");
        loanAppDTO.setCustId("CUST002");
        loanAppDTO.setLoanAmt(150000);
        loanAppDTO.setNoOfYears(3);
        loanAppDTO.setPurpose("Car Purchase");
        loanAppDTO.setAppStatus("Approved");
        loanAppDTO.setTypeOfLoan("Auto Loan");
        loanAppDTO.setLoanAppDate(new Date());
        loanAppDTO.setStatus("no status");

        loanAppDTOList.add(loanAppDTO);

        try {
            when(loanApplicationService.getAllLoanApplicationsByDate(Mockito.any(Date.class))).thenReturn(loanAppDTOList);
            ResponseEntity<List<LoanAppDTO>> responseEntity=customerManagementController.getAllLoanApplicationsByDate(new Date());
            assertEquals(200,responseEntity.getStatusCodeValue());
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testGetAllLoanApplicationsByDateNegativeAssertReturnValue() {
        List<LoanAppDTO> loanAppDTOList=new ArrayList<>();
        try {
            when(loanApplicationService.getAllLoanApplicationsByDate(Mockito.any(Date.class))).thenReturn(loanAppDTOList);
            ResponseEntity<List<LoanAppDTO>> responseEntity=customerManagementController.getAllLoanApplicationsByDate(new Date());
            assertNull(responseEntity.getBody());
        }catch(Exception e) {
//            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void testGetAllLoanApplicationsByDateNegativeAssertStatusCode() {
        List<LoanAppDTO> loanAppDTOList=new ArrayList<>();
        try {
            when(loanApplicationService.getAllLoanApplicationsByDate(Mockito.any(Date.class))).thenReturn(loanAppDTOList);
            ResponseEntity<List<LoanAppDTO>> responseEntity=customerManagementController.getAllLoanApplicationsByDate(new Date());
            assertEquals(400,responseEntity.getStatusCodeValue());
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testUpdateLoanApplicationWhenLoanApplicationIsValid() {
        LoanAppDTO loanAppDTO=new LoanAppDTO();
        loanAppDTO.setLoanAppId("LOAN001");
        loanAppDTO.setCustId("CUST01");
        loanAppDTO.setLoanAmt(240000);
        loanAppDTO.setNoOfYears(8);
        loanAppDTO.setPurpose("Home Renovation");
        loanAppDTO.setAppStatus("NewLoan");
        loanAppDTO.setTypeOfLoan("Business Loan");
        loanAppDTO.setLoanAppDate(new Date());
        loanAppDTO.setStatus("accepted");

        validator.validate(loanAppDTO).stream().forEach((constraintViolation)->assertNull(constraintViolation));
    }

    @Test
    public void testUpdateLoanApplicationPositiveAssertReturnvalue() {
        LoanAppDTO loanAppDTO=new LoanAppDTO();
        loanAppDTO.setLoanAppId("LOAN001");
        loanAppDTO.setCustId("CUST01");
        loanAppDTO.setLoanAmt(240000);
        loanAppDTO.setNoOfYears(8);
        loanAppDTO.setPurpose("Home Renovation");
        loanAppDTO.setAppStatus("NewLoan");
        loanAppDTO.setTypeOfLoan("Business Loan");
        loanAppDTO.setLoanAppDate(new Date());
        loanAppDTO.setStatus("accepted");

        try {
            when(loanApplicationService.updateLoanApplication(Mockito.anyString(),Mockito.any())).thenReturn(loanAppDTO);
            ResponseEntity<LoanAppDTO> responseEntity=customerManagementController.updateLoanApplication("LOAN001",loanAppDTO);
            LoanAppDTO actualLoanAppDTO=responseEntity.getBody();
            assertNotNull(actualLoanAppDTO);
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testUpdateLoanApplicationPositiveAssertStatusCode() {
        LoanAppDTO loanAppDTO=new LoanAppDTO();
        loanAppDTO.setLoanAppId("LOAN001");
        loanAppDTO.setCustId("CUST01");
        loanAppDTO.setLoanAmt(240000);
        loanAppDTO.setNoOfYears(8);
        loanAppDTO.setPurpose("Home Renovation");
        loanAppDTO.setAppStatus("NewLoan");
        loanAppDTO.setTypeOfLoan("Business Loan");
        loanAppDTO.setLoanAppDate(new Date());
        loanAppDTO.setStatus("accepted");

        try {
            when(loanApplicationService.updateLoanApplication(Mockito.anyString(),Mockito.any())).thenReturn(loanAppDTO);
            ResponseEntity<LoanAppDTO> responseEntity=customerManagementController.updateLoanApplication("LOAN001",loanAppDTO);
            assertEquals(202,responseEntity.getStatusCodeValue());
        }catch(Exception e) {
//            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void testUpdateLoanApplicationWhenLoanApplicationIsNotValid() {
        LoanAppDTO loanAppDTO = new LoanAppDTO();
        loanAppDTO.setLoanAppId("LOAN002");
        loanAppDTO.setCustId("CUST02");
        loanAppDTO.setLoanAmt(0);
        loanAppDTO.setNoOfYears(0);
        loanAppDTO.setPurpose("Car Purchase");
        loanAppDTO.setAppStatus("Sanctioned");
        loanAppDTO.setTypeOfLoan("Auto Loan");
        loanAppDTO.setLoanAppDate(new Date());
        loanAppDTO.setStatus("accepted");

        validator.validate(loanAppDTO).stream().forEach((constraintViolation)->assertNotNull(constraintViolation));
    }

    @Test
    public void testUpdateLoanApplicationNegativeAssertReturnvalue() {
        LoanAppDTO loanAppDTO=null;

        try {
            when(loanApplicationService.updateLoanApplication(Mockito.anyString(),Mockito.any())).thenReturn(loanAppDTO);
            ResponseEntity<LoanAppDTO> responseEntity=customerManagementController.updateLoanApplication("LOAN002",loanAppDTO);
            LoanAppDTO actualLoanAppDTO=responseEntity.getBody();
            assertNull(actualLoanAppDTO);
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testUpdateLoanApplicationNegativeAssertStatusCode() {
        LoanAppDTO loanAppDTO=null;

        try {
            when(loanApplicationService.updateLoanApplication(Mockito.anyString(),Mockito.any())).thenReturn(loanAppDTO);
            ResponseEntity<LoanAppDTO> responseEntity=customerManagementController.updateLoanApplication("LOAN002",loanAppDTO);
            assertEquals(400,responseEntity.getStatusCodeValue());
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testGetAllReducedPaymentsPositiveAssertReturnValue() {
        List<ReducedPaymentDTO> reducedPaymentDTOList=new ArrayList<>();

        ReducedPaymentDTO reducedPaymentDTO=new ReducedPaymentDTO();
        reducedPaymentDTO.setLoanAppId("LOAN002");
        reducedPaymentDTO.setMonthNo(1);
        reducedPaymentDTO.setInstallment(15000);
        reducedPaymentDTO.setInterestRate(6);
        reducedPaymentDTO.setLoanAmt(150000);
        reducedPaymentDTO.setNoOfYears(3);
        reducedPaymentDTO.setPOutstandingBeginOfMonth(150000);
        reducedPaymentDTO.setPRepayment(10000);
        reducedPaymentDTO.setPrOutstandingEndOfMonth(140000);
        reducedPaymentDTO.setReducedPayment(810);

        reducedPaymentDTOList.add(reducedPaymentDTO);

        try {
            when(reducedPaymentService.getAllReducedPayments(Mockito.anyString())).thenReturn(reducedPaymentDTOList);
            ResponseEntity<List<ReducedPaymentDTO>> responseEntity=customerManagementController.getAllReducedPayments("LOAN002");
            List<ReducedPaymentDTO> actualReducedPaymentDTOList=responseEntity.getBody();
            assertTrue(actualReducedPaymentDTOList.size()>0);
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testGetAllReducedPaymentsPositiveAssertStatusCode() {
        List<ReducedPaymentDTO> reducedPaymentDTOList=new ArrayList<>();

        ReducedPaymentDTO reducedPaymentDTO=new ReducedPaymentDTO();
        reducedPaymentDTO.setLoanAppId("LOAN002");
        reducedPaymentDTO.setMonthNo(1);
        reducedPaymentDTO.setInstallment(15000);
        reducedPaymentDTO.setInterestRate(6);
        reducedPaymentDTO.setLoanAmt(150000);
        reducedPaymentDTO.setNoOfYears(3);
        reducedPaymentDTO.setPOutstandingBeginOfMonth(150000);
        reducedPaymentDTO.setPRepayment(10000);
        reducedPaymentDTO.setPrOutstandingEndOfMonth(140000);
        reducedPaymentDTO.setReducedPayment(810);

        reducedPaymentDTOList.add(reducedPaymentDTO);

        try {
            when(reducedPaymentService.getAllReducedPayments(Mockito.anyString())).thenReturn(reducedPaymentDTOList);
            ResponseEntity<List<ReducedPaymentDTO>> responseEntity=customerManagementController.getAllReducedPayments("LOAN002");
            assertEquals(200,responseEntity.getStatusCodeValue());
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testGetAllReducedPaymentsNegativeAssertReturnValue() {
        List<ReducedPaymentDTO> reducedPaymentDTOList=new ArrayList<>();
        try {
            when(reducedPaymentService.getAllReducedPayments(Mockito.anyString())).thenReturn(reducedPaymentDTOList);
            ResponseEntity<List<ReducedPaymentDTO>> responseEntity=customerManagementController.getAllReducedPayments("LOAN002");
            assertNull(responseEntity.getBody());
        }catch(Exception e) {
//            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void testGetAllReducedPaymentsNegativeAssertStatusCode() {
        List<ReducedPaymentDTO> reducedPaymentDTOList=new ArrayList<>();
        try {
            when(reducedPaymentService.getAllReducedPayments(Mockito.anyString())).thenReturn(reducedPaymentDTOList);
            ResponseEntity<List<ReducedPaymentDTO>> responseEntity=customerManagementController.getAllReducedPayments("LOAN002");
            assertEquals(400,responseEntity.getStatusCodeValue());
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testAddLoanApplicationWhenLoanApplicationIsValid() {
        LoanAppDTO loanAppDTO = new LoanAppDTO();
        loanAppDTO.setLoanAppId("LOAN001");
        loanAppDTO.setCustId("CUST01");
        loanAppDTO.setLoanAmt(200000);
        loanAppDTO.setNoOfYears(5);
        loanAppDTO.setPurpose("Home Renovation");
        loanAppDTO.setAppStatus("NewLoan");
        loanAppDTO.setTypeOfLoan("Home Loan");
        loanAppDTO.setLoanAppDate(new Date());
        loanAppDTO.setStatus("accepted");

        validator.validate(loanAppDTO).stream().forEach((constraintViolation)->assertNull(constraintViolation));
    }

    @Test
    public void testAddLoanApplicationPositiveAssertReturnvalue() {
        LoanAppDTO loanAppDTO = new LoanAppDTO();
        loanAppDTO.setLoanAppId("LOAN001");
        loanAppDTO.setCustId("CUST01");
        loanAppDTO.setLoanAmt(200000);
        loanAppDTO.setNoOfYears(5);
        loanAppDTO.setPurpose("Home Renovation");
        loanAppDTO.setAppStatus("NewLoan");
        loanAppDTO.setTypeOfLoan("Home Loan");
        loanAppDTO.setLoanAppDate(new Date());
        loanAppDTO.setStatus("accepted");

        try {
            when(loanApplicationService.addLoanApplication(Mockito.any())).thenReturn(loanAppDTO);
            ResponseEntity<LoanAppDTO> responseEntity=customerManagementController.addLoanApplication(loanAppDTO);
            LoanAppDTO actualLoanAppDTO =responseEntity.getBody();
            assertNotNull(actualLoanAppDTO);
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testAddLoanApplicationPositiveAssertStatusCode() {
        LoanAppDTO loanAppDTO = new LoanAppDTO();
        loanAppDTO.setLoanAppId("LOAN001");
        loanAppDTO.setCustId("CUST01");
        loanAppDTO.setLoanAmt(200000);
        loanAppDTO.setNoOfYears(5);
        loanAppDTO.setPurpose("Home Renovation");
        loanAppDTO.setAppStatus("NewLoan");
        loanAppDTO.setTypeOfLoan("Home Loan");
        loanAppDTO.setLoanAppDate(new Date());
        loanAppDTO.setStatus("accepted");

        try {
            when(loanApplicationService.addLoanApplication(Mockito.any())).thenReturn(loanAppDTO);
            ResponseEntity<LoanAppDTO> responseEntity=customerManagementController.addLoanApplication(loanAppDTO);
            assertEquals(201,responseEntity.getStatusCodeValue());
        }catch(Exception e) {
//            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void testAddLoanApplicationWhenLoanApplicationIsNotValid() {
        LoanAppDTO loanAppDTO = new LoanAppDTO();
        loanAppDTO.setLoanAppId("LOAN001");
        loanAppDTO.setCustId("CUST01");
        loanAppDTO.setLoanAmt(200000);
        loanAppDTO.setNoOfYears(5);
        loanAppDTO.setPurpose("Home Renovation");
        loanAppDTO.setAppStatus("NewLoanApproved");
        loanAppDTO.setTypeOfLoan("Home Loan");
        loanAppDTO.setLoanAppDate(new Date(2024,10,8));
        loanAppDTO.setStatus("acceptedrejected");

        validator.validate(loanAppDTO).stream().forEach((constraintViolation)->assertNotNull(constraintViolation));
    }

    @Test
    public void testAddLoanApplicationNegativeAssertReturnvalue() {
        LoanAppDTO loanAppDTO=null;

        try {
            when(loanApplicationService.addLoanApplication(Mockito.any())).thenReturn(loanAppDTO);
            ResponseEntity<LoanAppDTO> responseEntity=customerManagementController.addLoanApplication(loanAppDTO);
            LoanAppDTO actualLoanAppDTO=responseEntity.getBody();
            assertNull(actualLoanAppDTO);
        }catch(Exception e) {
            assertTrue(false);
        }
    }

    @Test
    public void testAddLoanApplicationNegativeAssertStatusCode() {
        LoanAppDTO loanAppDTO=null;

        try {
            when(loanApplicationService.addLoanApplication(Mockito.any())).thenReturn(loanAppDTO);
            ResponseEntity<LoanAppDTO> responseEntity=customerManagementController.addLoanApplication(loanAppDTO);
            assertEquals(400,responseEntity.getStatusCodeValue());
        }catch(Exception e) {
            assertTrue(false);
        }
    }
}
