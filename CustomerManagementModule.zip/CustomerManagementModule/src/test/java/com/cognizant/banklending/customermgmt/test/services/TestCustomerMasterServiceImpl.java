package com.cognizant.banklending.customermgmt.test.services;

import com.cognizant.banklending.customermgmt.dtos.CustomerDTO;
import com.cognizant.banklending.customermgmt.entities.CustomerMaster;
import com.cognizant.banklending.customermgmt.entities.LoanApplication;
import com.cognizant.banklending.customermgmt.exceptions.DuplicateAccountException;
import com.cognizant.banklending.customermgmt.repositories.CustomerMasterRepository;
import com.cognizant.banklending.customermgmt.repositories.LoanApplicationRepository;
import com.cognizant.banklending.customermgmt.services.CustomerMasterServiceImpl;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.modelmapper.ModelMapper;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class TestCustomerMasterServiceImpl {
    @Mock
    private CustomerMasterRepository customerMasterRepository;

    @Mock
    private LoanApplicationRepository loanApplicationRepository;

    @Mock
    private ModelMapper modelMapper;

    @InjectMocks
    private CustomerMasterServiceImpl customerMasterServiceImpl;

    @BeforeEach
    void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
    }

    @AfterEach
    void tearDown() throws Exception {

    }

    @Test
    public void testGetAllCustomersPositiveOneCustomerFound() {
        try {
            List<CustomerMaster> listCustomerMasterMock=mock(List.class);
            when(customerMasterRepository.findAll()).thenReturn(listCustomerMasterMock);
            Iterator<CustomerMaster> iteratorCustomerMasterMock =mock(Iterator.class);

            when(listCustomerMasterMock.iterator()).thenReturn(iteratorCustomerMasterMock);
            when(iteratorCustomerMasterMock.hasNext()).thenReturn(true).thenReturn(false);

            CustomerMaster customerMasterMock=mock(CustomerMaster.class);

            when(iteratorCustomerMasterMock.next()).thenReturn(customerMasterMock);

            CustomerDTO customerDTOMock=mock(CustomerDTO.class);

            when(modelMapper.map(Mockito.any(CustomerMaster.class), Mockito.eq(CustomerDTO.class))).thenReturn(customerDTOMock);

            List<CustomerDTO> customerDTOList =customerMasterServiceImpl.getAllCustomers();
//            System.out.println(customerDTOList.size());
            assertTrue(customerDTOList.size()==1);
        }catch(Exception e) {
            //	System.out.println(e);
            assertTrue(false);
        }
    }

    @Test
    public void testGetAllCustomersPositiveMultipleCustomersFound() {
        try {
            List<CustomerMaster> listCustomerMasterMock=mock(List.class);
            when(customerMasterRepository.findAll()).thenReturn(listCustomerMasterMock);
            Iterator<CustomerMaster> iteratorCustomerMasterMock =mock(Iterator.class);

            when(listCustomerMasterMock.iterator()).thenReturn(iteratorCustomerMasterMock);
            when(iteratorCustomerMasterMock.hasNext()).thenReturn(true).thenReturn(true).thenReturn(false);

            CustomerMaster customerMasterMock=mock(CustomerMaster.class);

            CustomerDTO customerDTOMock=mock(CustomerDTO.class);

            when(modelMapper.map(Mockito.any(CustomerMaster.class), Mockito.eq(CustomerDTO.class))).thenReturn(customerDTOMock);

            List<CustomerDTO> customerDTOList =customerMasterServiceImpl.getAllCustomers();
//            System.out.println(customerDTOList);

            assertTrue(customerDTOList.size()>1);
        }catch(Exception e) {
            //	System.out.println(e);
            assertTrue(false);
        }
    }

    @Test
    public void testGetAllCustomersException() {
        try {
            List<CustomerMaster> listCustomerMasterMock=mock(List.class);
            when(customerMasterRepository.findAll()).thenReturn(listCustomerMasterMock);
            Iterator<CustomerMaster> iteratorCustomerMasterMock =mock(Iterator.class);

            when(listCustomerMasterMock.iterator()).thenReturn(iteratorCustomerMasterMock);
            when(iteratorCustomerMasterMock.hasNext()).thenReturn(false);

            CustomerMaster customerMasterMock=mock(CustomerMaster.class);

            when(iteratorCustomerMasterMock.next()).thenReturn(customerMasterMock);

            CustomerDTO customerDTOMock=mock(CustomerDTO.class);

            when(modelMapper.map(Mockito.any(CustomerMaster.class), Mockito.eq(CustomerDTO.class))).thenReturn(customerDTOMock);

            List<CustomerDTO> customerDTOList =customerMasterServiceImpl.getAllCustomers();
            assertTrue(!customerDTOList.isEmpty());
        }catch(Exception e) {
            //	System.out.println(e);
            assertTrue(true);
        }
    }

    @Test
    public void testGetCustomerByIdPositive(){
        try{
            CustomerMaster customerMaster=new CustomerMaster();

            customerMaster.setCustId("CUST01");
            customerMaster.setCustFirstName("Adrineel");
            customerMaster.setCustLastName("Saha");
            customerMaster.setAddress("123 Street");
            customerMaster.setCity("Asansol");
            customerMaster.setContactNo(1234567890);
            customerMaster.setAdharCard(1456789012);
            customerMaster.setEmailId("adrineel.saha@cognizant.com");
            customerMaster.setBirthDate(new Date(2001,10,18));
            customerMaster.setMonthlySalary(65000);

            when(customerMasterRepository.findById(Mockito.anyString())).thenReturn(Optional.of(customerMaster));

            CustomerDTO custDTO=new CustomerDTO();
            custDTO.setCustId("CUST01");
            custDTO.setCustFirstName("Adrineel");
            custDTO.setCustLastName("Saha");
            custDTO.setAddress("123 Street");
            custDTO.setCity("Asansol");
            custDTO.setContactNo(1234567890);
            custDTO.setAdharCard(1456789012);
            custDTO.setEmailId("adrineel.saha@cognizant.com");
            custDTO.setBirthDate(new Date(2001,10,18));
            custDTO.setMonthlySalary(65000);

            when(modelMapper.map(Mockito.any(CustomerMaster.class), Mockito.eq(CustomerDTO.class))).thenReturn(custDTO);

            CustomerDTO customerDTO=customerMasterServiceImpl.getCustomerById("CUST01");
            assertNotNull(customerDTO);
        } catch(Exception e){
//            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void testGetCustomerByIdNegative(){
        try{
            when(customerMasterRepository.findById(Mockito.anyString())).thenReturn(Optional.empty());
//            when(modelMapper.map(Mockito.any(CustomerMaster.class), Mockito.eq(CustomerDTO.class))).thenReturn(null);

            CustomerDTO customerDTO=customerMasterServiceImpl.getCustomerById("CUST01");
            assertNotNull(customerDTO);
        } catch(Exception e){
//            e.printStackTrace();
            assertTrue(true);
        }
    }

    @Test
    public void testAddCustomerPositive() {
        try {
            CustomerDTO customerDTO =new CustomerDTO();
            customerDTO.setCustId("CUST02");
            customerDTO.setCustFirstName("Arunabh");
            customerDTO.setCustLastName("Kalita");
            customerDTO.setAddress("456 Avenue");
            customerDTO.setCity("Dibrugarh");
            customerDTO.setContactNo(1876543210);
            customerDTO.setAdharCard(1456701234);
            customerDTO.setEmailId("arunabh.kalita@cognizant.com");
            customerDTO.setBirthDate(new SimpleDateFormat("yyyy-MM-dd").parse("2000-06-15"));
            customerDTO.setMonthlySalary(60000);

            CustomerMaster customerMaster=new CustomerMaster();
            customerMaster.setCustId("CUST02");
            customerMaster.setCustFirstName("Arunabh");
            customerMaster.setCustLastName("Kalita");
            customerMaster.setAddress("456 Avenue");
            customerMaster.setCity("Dibrugarh");
            customerMaster.setContactNo(1876543210);
            customerMaster.setAdharCard(1456701234);
            customerMaster.setEmailId("arunabh.kalita@cognizant.com");
            customerMaster.setBirthDate(new Date(2000,5,15));
            customerMaster.setMonthlySalary(60000);

            when(modelMapper.map(Mockito.any(CustomerDTO.class), Mockito.eq(CustomerMaster.class))).thenReturn(customerMaster);
            when(customerMasterRepository.save(Mockito.any())).thenReturn(customerMaster);
            when(modelMapper.map(Mockito.any(CustomerMaster.class), Mockito.eq(CustomerDTO.class))).thenReturn(customerDTO);

            CustomerDTO actualCustomerDTO=customerMasterServiceImpl.addCustomer(customerDTO);
            assertNotNull(actualCustomerDTO);
        }catch(Exception e) {
//            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void testAddCustomerNegative() {
        try {
            CustomerDTO customerDTO =new CustomerDTO();
            customerDTO.setCustId("CUST02");
            customerDTO.setCustFirstName("Ar");
            customerDTO.setCustLastName("Ka");
            customerDTO.setAddress("456 Avenue");
            customerDTO.setCity("Dibrugarh");
            customerDTO.setContactNo(1876543210);
            customerDTO.setAdharCard(1456701234);
            customerDTO.setEmailId("arunabh.kalita@gmail.com");
            customerDTO.setBirthDate(new SimpleDateFormat("yyyy-MM-dd").parse("2000-06-15"));
            customerDTO.setMonthlySalary(60000);

            CustomerMaster customerMaster=new CustomerMaster();
            customerMaster.setCustId("CUST02");
            customerMaster.setCustFirstName("Ar");
            customerMaster.setCustLastName("Ka");
            customerMaster.setAddress("456 Avenue");
            customerMaster.setCity("Dibrugarh");
            customerMaster.setContactNo(1876543210);
            customerMaster.setAdharCard(1456701234);
            customerMaster.setEmailId("arunabh.kalita@gmail.com");
            customerMaster.setBirthDate(new Date(2000,5,15));
            customerMaster.setMonthlySalary(60000);

            when(modelMapper.map(Mockito.any(CustomerDTO.class), Mockito.eq(CustomerMaster.class))).thenReturn(customerMaster);
            when(customerMasterRepository.save(Mockito.any())).thenReturn(customerMaster);
            when(modelMapper.map(Mockito.any(CustomerMaster.class), Mockito.eq(CustomerDTO.class))).thenReturn(customerDTO);

            CustomerDTO actualCustomerDTO=customerMasterServiceImpl.addCustomer(customerDTO);
            assertNotNull(actualCustomerDTO);
        }catch(Exception e) {
//            e.printStackTrace();
            assertTrue(true);
        }
    }

    @Test
    public void testAddCustomerAgeBarException() {
        try {
            CustomerDTO customerDTO =new CustomerDTO();
            customerDTO.setCustId("CUST02");
            customerDTO.setCustFirstName("Arunabh");
            customerDTO.setCustLastName("Kalita");
            customerDTO.setAddress("456 Avenue");
            customerDTO.setCity("Dibrugarh");
            customerDTO.setContactNo(1876543210);
            customerDTO.setAdharCard(1456701234);
            customerDTO.setEmailId("arunabh.kalita@cognizant.com");
            customerDTO.setBirthDate(new SimpleDateFormat("yyyy-MM-dd").parse("2010-06-15"));
            customerDTO.setMonthlySalary(60000);

            CustomerMaster customerMaster=new CustomerMaster();
            customerMaster.setCustId("CUST02");
            customerMaster.setCustFirstName("Arunabh");
            customerMaster.setCustLastName("Kalita");
            customerMaster.setAddress("456 Avenue");
            customerMaster.setCity("Dibrugarh");
            customerMaster.setContactNo(1876543210);
            customerMaster.setAdharCard(1456701234);
            customerMaster.setEmailId("arunabh.kalita@cognizant.com");
            customerMaster.setBirthDate(new Date(2010,5,15));
            customerMaster.setMonthlySalary(60000);

            when(modelMapper.map(Mockito.any(CustomerDTO.class), Mockito.eq(CustomerMaster.class))).thenReturn(customerMaster);
//            when(customerMasterRepository.save(Mockito.any())).thenThrow(new AgeBarException("Age should be between 18 and 58"));
            when(customerMasterRepository.save(Mockito.any())).thenReturn(customerMaster);
            when(modelMapper.map(Mockito.any(CustomerMaster.class), Mockito.eq(CustomerDTO.class))).thenReturn(customerDTO);

            CustomerDTO actualCustomerDTO=customerMasterServiceImpl.addCustomer(customerDTO);
            assertNotNull(actualCustomerDTO);
        }catch(Exception e) {
//            e.printStackTrace();
            assertTrue(true);
        }
    }

    @Test
    public void testAddCustomerDuplicateAccountException() {
        try {
            CustomerDTO customerDTO =new CustomerDTO();
            customerDTO.setCustId("CUST02");
            customerDTO.setCustFirstName("Arunabh");
            customerDTO.setCustLastName("Kalita");
            customerDTO.setAddress("456 Avenue");
            customerDTO.setCity("Dibrugarh");
            customerDTO.setContactNo(1876543210);
            customerDTO.setAdharCard(1456701234);
            customerDTO.setEmailId("arunabh.kalita@cognizant.com");
            customerDTO.setBirthDate(new SimpleDateFormat("yyyy-MM-dd").parse("2000-06-15"));
            customerDTO.setMonthlySalary(60000);

            CustomerMaster customerMaster=new CustomerMaster();
            customerMaster.setCustId("CUST02");
            customerMaster.setCustFirstName("Arunabh");
            customerMaster.setCustLastName("Kalita");
            customerMaster.setAddress("456 Avenue");
            customerMaster.setCity("Dibrugarh");
            customerMaster.setContactNo(1876543210);
            customerMaster.setAdharCard(1456701234);
            customerMaster.setEmailId("arunabh.kalita@cognizant.com");
            customerMaster.setBirthDate(new Date(2000,5,15));
            customerMaster.setMonthlySalary(60000);

            when(modelMapper.map(Mockito.any(CustomerDTO.class), Mockito.eq(CustomerMaster.class))).thenReturn(customerMaster);
            when(customerMasterRepository.save(Mockito.any())).thenThrow(new DuplicateAccountException("User already present with Adhar Id: " + customerDTO.getAdharCard()));
//            when(customerMasterRepository.save(Mockito.any())).thenReturn(customerMaster);
//            when(modelMapper.map(Mockito.any(CustomerMaster.class), Mockito.eq(CustomerDTO.class))).thenReturn(customerDTO);

            CustomerDTO actualCustomerDTO=customerMasterServiceImpl.addCustomer(customerDTO);
            assertNotNull(actualCustomerDTO);
        }catch(Exception e) {
//            e.printStackTrace();
            assertTrue(true);
        }
    }

    @Test
    public void TestUpdateCustomerPositive(){
        try{
            CustomerMaster customerMaster=new CustomerMaster();
            customerMaster.setCustId("CUST02");
            customerMaster.setCustFirstName("Arunabh");
            customerMaster.setCustLastName("Kalita");
            customerMaster.setAddress("456 Avenue");
            customerMaster.setCity("Dibrugarh");
            customerMaster.setContactNo(1876543210);
            customerMaster.setAdharCard(1456701234);
            customerMaster.setEmailId("arunabh.kalita@cognizant.com");
            customerMaster.setBirthDate(new Date(2000,5,15));
            customerMaster.setMonthlySalary(60000);

            Optional<CustomerMaster> customerMasterOptional=Optional.of(customerMaster);
            when(customerMasterRepository.findById("CUST02")).thenReturn(customerMasterOptional);

            CustomerDTO customerDTO =new CustomerDTO();
            customerDTO.setCustId("CUST02");
            customerDTO.setCustFirstName("Akash");
            customerDTO.setCustLastName("Banerjee");
            customerDTO.setAddress("546 Avenue");
            customerDTO.setCity("Asansol");
            customerDTO.setContactNo(1776543210);
            customerDTO.setAdharCard(1567891123);
            customerDTO.setEmailId("akash.banerjee@cognizant.com");
            customerDTO.setBirthDate(new SimpleDateFormat("yyyy-MM-dd").parse("2001-05-15"));
            customerDTO.setMonthlySalary(55000);

            CustomerMaster updatedCustomerMaster =new CustomerMaster();
            updatedCustomerMaster.setCustId("CUST02");
            updatedCustomerMaster.setCustFirstName("Akash");
            updatedCustomerMaster.setCustLastName("Banerjee");
            updatedCustomerMaster.setAddress("546 Avenue");
            updatedCustomerMaster.setCity("Asansol");
            updatedCustomerMaster.setContactNo(1776543210);
            updatedCustomerMaster.setAdharCard(1567891123);
            updatedCustomerMaster.setEmailId("akash.banerjee@cognizant.com");
            updatedCustomerMaster.setBirthDate(new Date(2001,5,15));
            updatedCustomerMaster.setMonthlySalary(55000);

            when(customerMasterRepository.save(Mockito.any())).thenReturn(updatedCustomerMaster);
            when(modelMapper.map(Mockito.any(CustomerMaster.class), Mockito.eq(CustomerDTO.class))).thenReturn(customerDTO);

            CustomerDTO actualCustomerDTO=customerMasterServiceImpl.updateCustomer("CUST02",customerDTO);
            assertNotNull(actualCustomerDTO);
        }catch(Exception e){
//            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void TestUpdateCustomerNegative(){
        try{
            CustomerMaster customerMaster=new CustomerMaster();
            customerMaster.setCustId("CUST02");
            customerMaster.setCustFirstName("Arunabh");
            customerMaster.setCustLastName("Kalita");
            customerMaster.setAddress("456 Avenue");
            customerMaster.setCity("Dibrugarh");
            customerMaster.setContactNo(1876543210);
            customerMaster.setAdharCard(1456701234);
            customerMaster.setEmailId("arunabh.kalita@cognizant.com");
            customerMaster.setBirthDate(new Date(2000,5,15));
            customerMaster.setMonthlySalary(60000);

            Optional<CustomerMaster> customerMasterOptional=Optional.of(customerMaster);
            when(customerMasterRepository.findById("CUST02")).thenReturn(customerMasterOptional);

            CustomerDTO customerDTO =new CustomerDTO();
            customerDTO.setCustId("CUST02");
            customerDTO.setCustFirstName("Ak");
            customerDTO.setCustLastName("Ba");
            customerDTO.setAddress("546 Avenue");
            customerDTO.setCity("Asansol");
            customerDTO.setContactNo(1776543210);
            customerDTO.setAdharCard(1567891123);
            customerDTO.setEmailId("akash.banerjee@gmail.com");
            customerDTO.setBirthDate(new SimpleDateFormat("yyyy-MM-dd").parse("2001-05-15"));
            customerDTO.setMonthlySalary(55000);

            CustomerMaster updatedCustomerMaster =new CustomerMaster();
            updatedCustomerMaster.setCustId("CUST02");
            updatedCustomerMaster.setCustFirstName("Ak");
            updatedCustomerMaster.setCustLastName("Ba");
            updatedCustomerMaster.setAddress("546 Avenue");
            updatedCustomerMaster.setCity("Asansol");
            updatedCustomerMaster.setContactNo(1776543210);
            updatedCustomerMaster.setAdharCard(1567891123);
            updatedCustomerMaster.setEmailId("akash.banerjee@gmail.com");
            updatedCustomerMaster.setBirthDate(new Date(2001,5,15));
            updatedCustomerMaster.setMonthlySalary(55000);

            when(customerMasterRepository.save(Mockito.any())).thenReturn(updatedCustomerMaster);
            when(modelMapper.map(Mockito.any(CustomerMaster.class), Mockito.eq(CustomerDTO.class))).thenReturn(customerDTO);

            CustomerDTO actualCustomerDTO=customerMasterServiceImpl.updateCustomer("CUST02",customerDTO);
            assertNotNull(actualCustomerDTO);
        }catch(Exception e){
//            e.printStackTrace();
            assertTrue(true);
        }
    }

    @Test
    public void TestUpdateCustomerAgeBarException(){
        try{
            CustomerMaster customerMaster=new CustomerMaster();
            customerMaster.setCustId("CUST02");
            customerMaster.setCustFirstName("Arunabh");
            customerMaster.setCustLastName("Kalita");
            customerMaster.setAddress("456 Avenue");
            customerMaster.setCity("Dibrugarh");
            customerMaster.setContactNo(1876543210);
            customerMaster.setAdharCard(1456701234);
            customerMaster.setEmailId("arunabh.kalita@cognizant.com");
            customerMaster.setBirthDate(new Date(2000,5,15));
            customerMaster.setMonthlySalary(60000);

            Optional<CustomerMaster> customerMasterOptional=Optional.of(customerMaster);
            when(customerMasterRepository.findById("CUST02")).thenReturn(customerMasterOptional);

            CustomerDTO customerDTO =new CustomerDTO();
            customerDTO.setCustId("CUST02");
            customerDTO.setCustFirstName("Akash");
            customerDTO.setCustLastName("Banerjee");
            customerDTO.setAddress("546 Avenue");
            customerDTO.setCity("Asansol");
            customerDTO.setContactNo(1776543210);
            customerDTO.setAdharCard(1567891123);
            customerDTO.setEmailId("akash.banerjee@cognizant.com");
            customerDTO.setBirthDate(new SimpleDateFormat("yyyy-MM-dd").parse("2010-05-15"));
            customerDTO.setMonthlySalary(55000);

            CustomerMaster updatedCustomerMaster =new CustomerMaster();
            updatedCustomerMaster.setCustId("CUST02");
            updatedCustomerMaster.setCustFirstName("Akash");
            updatedCustomerMaster.setCustLastName("Banerjee");
            updatedCustomerMaster.setAddress("546 Avenue");
            updatedCustomerMaster.setCity("Asansol");
            updatedCustomerMaster.setContactNo(1776543210);
            updatedCustomerMaster.setAdharCard(1567891123);
            updatedCustomerMaster.setEmailId("akash.banerjee@cognizant.com");
            updatedCustomerMaster.setBirthDate(new Date(2010,5,15));
            updatedCustomerMaster.setMonthlySalary(55000);

            when(customerMasterRepository.save(Mockito.any())).thenReturn(updatedCustomerMaster);
            when(modelMapper.map(Mockito.any(CustomerMaster.class), Mockito.eq(CustomerDTO.class))).thenReturn(customerDTO);

            CustomerDTO actualCustomerDTO=customerMasterServiceImpl.updateCustomer("CUST02",customerDTO);
            assertNotNull(actualCustomerDTO);
        }catch(Exception e){
//            e.printStackTrace();
            assertTrue(true);
        }
    }

    @Test
    public void TestUpdateCustomerDuplicateAccountException(){
        try{
            CustomerMaster customerMaster=new CustomerMaster();
            customerMaster.setCustId("CUST02");
            customerMaster.setCustFirstName("Arunabh");
            customerMaster.setCustLastName("Kalita");
            customerMaster.setAddress("456 Avenue");
            customerMaster.setCity("Dibrugarh");
            customerMaster.setContactNo(1876543210);
            customerMaster.setAdharCard(1456701234);
            customerMaster.setEmailId("arunabh.kalita@cognizant.com");
            customerMaster.setBirthDate(new Date(2000,5,15));
            customerMaster.setMonthlySalary(60000);

            Optional<CustomerMaster> customerMasterOptional=Optional.of(customerMaster);
            when(customerMasterRepository.findById("CUST02")).thenReturn(customerMasterOptional);

            CustomerDTO customerDTO =new CustomerDTO();
            customerDTO.setCustId("CUST02");
            customerDTO.setCustFirstName("Akash");
            customerDTO.setCustLastName("Banerjee");
            customerDTO.setAddress("546 Avenue");
            customerDTO.setCity("Asansol");
            customerDTO.setContactNo(1776543210);
            customerDTO.setAdharCard(1567891123);
            customerDTO.setEmailId("akash.banerjee@cognizant.com");
            customerDTO.setBirthDate(new SimpleDateFormat("yyyy-MM-dd").parse("2001-05-15"));
            customerDTO.setMonthlySalary(55000);

            when(customerMasterRepository.save(Mockito.any())).thenThrow(new DuplicateAccountException("User already present with Adhar Id: " + customerDTO.getAdharCard()));
//            when(customerMasterRepository.save(Mockito.any())).thenReturn(updatedCustomerMaster);
//            when(modelMapper.map(Mockito.any(CustomerMaster.class), Mockito.eq(CustomerDTO.class))).thenReturn(customerDTO);

            CustomerDTO actualCustomerDTO=customerMasterServiceImpl.updateCustomer("CUST02",customerDTO);
            assertNotNull(actualCustomerDTO);
        }catch(Exception e){
//            e.printStackTrace();
            assertTrue(true);
        }
    }

    @Test
    public void testGetAllCustomersByStatusPositiveOneCustomerFound() {
        try {
            List<LoanApplication> loanApplicationList=mock(List.class);

            when(loanApplicationRepository.findByAppStatus(Mockito.anyString())).thenReturn(loanApplicationList);
//            Iterable<CustomerMaster> iterableCustomerMasterMock=mock(Iterable.class);
//            when(customerMasterRepository.findAll()).thenReturn(iterableCustomerMasterMock);
            Iterator<LoanApplication> iteratorLoanApplicationMock =mock(Iterator.class);

            when(loanApplicationList.iterator()).thenReturn(iteratorLoanApplicationMock);
            when(iteratorLoanApplicationMock.hasNext()).thenReturn(true).thenReturn(false);

//            CustomerMaster customerMasterMock=mock(CustomerMaster.class);

            LoanApplication loanApplicationMock=mock(LoanApplication.class);
            when(iteratorLoanApplicationMock.next()).thenReturn(loanApplicationMock);

            CustomerMaster customerMasterMock=mock(CustomerMaster.class);
            when(loanApplicationMock.getCustomerMaster()).thenReturn(customerMasterMock);

            CustomerDTO customerDTOMock=mock(CustomerDTO.class);
            when(modelMapper.map(Mockito.any(CustomerMaster.class), Mockito.eq(CustomerDTO.class))).thenReturn(customerDTOMock);

            List<CustomerDTO> customerDTOList =customerMasterServiceImpl.getAllCustomersByStatus("Sanctioned");

            assertTrue(customerDTOList.size()==1);
        }catch(Exception e) {
            //	System.out.println(e);
            assertTrue(false);
        }
    }

    @Test
    public void testGetAllCustomersByStatusPositiveMultipleCustomersFound() {
        try {
            List<LoanApplication> loanApplicationList=mock(List.class);

            when(loanApplicationRepository.findByAppStatus(Mockito.anyString())).thenReturn(loanApplicationList);
//            Iterable<CustomerMaster> iterableCustomerMasterMock=mock(Iterable.class);
//            when(customerMasterRepository.findAll()).thenReturn(iterableCustomerMasterMock);
            Iterator<LoanApplication> iteratorLoanApplicationMock =mock(Iterator.class);

            when(loanApplicationList.iterator()).thenReturn(iteratorLoanApplicationMock);
            when(iteratorLoanApplicationMock.hasNext()).thenReturn(true).thenReturn(true).thenReturn(false);

//            CustomerMaster customerMasterMock=mock(CustomerMaster.class);

            LoanApplication loanApplicationMock=mock(LoanApplication.class);
            when(iteratorLoanApplicationMock.next()).thenReturn(loanApplicationMock);

            CustomerMaster customerMasterMock=mock(CustomerMaster.class);
            when(loanApplicationMock.getCustomerMaster()).thenReturn(customerMasterMock);

            CustomerDTO customerDTOMock=mock(CustomerDTO.class);
            when(modelMapper.map(Mockito.any(CustomerMaster.class), Mockito.eq(CustomerDTO.class))).thenReturn(customerDTOMock);

            List<CustomerDTO> customerDTOList =customerMasterServiceImpl.getAllCustomersByStatus("Approved");

            assertTrue(customerDTOList.size()>1);
        }catch(Exception e) {
            //	System.out.println(e);
            assertTrue(false);
        }
    }

    @Test
    public void testGetAllCustomersByStatusException() {
        try {
            List<LoanApplication> listLoanApplicationMOCK =mock(List.class);

            when(loanApplicationRepository.findByAppStatus(Mockito.anyString())).thenReturn(listLoanApplicationMOCK);
//            Iterable<CustomerMaster> iterableCustomerMasterMock=mock(Iterable.class);
//            when(customerMasterRepository.findAll()).thenReturn(iterableCustomerMasterMock);
            Iterator<LoanApplication> iteratorLoanApplicationMock =mock(Iterator.class);

            when(listLoanApplicationMOCK.iterator()).thenReturn(iteratorLoanApplicationMock);
            when(iteratorLoanApplicationMock.hasNext()).thenReturn(false);

//            CustomerMaster customerMasterMock=mock(CustomerMaster.class);

            LoanApplication loanApplicationMock=mock(LoanApplication.class);
            when(iteratorLoanApplicationMock.next()).thenReturn(loanApplicationMock);

            CustomerMaster customerMasterMock=mock(CustomerMaster.class);
            when(loanApplicationMock.getCustomerMaster()).thenReturn(customerMasterMock);

            CustomerDTO customerDTOMock=mock(CustomerDTO.class);

            when(modelMapper.map(Mockito.any(CustomerMaster.class), Mockito.eq(CustomerDTO.class))).thenReturn(customerDTOMock);

            List<CustomerDTO> customerDTOList =customerMasterServiceImpl.getAllCustomersByStatus("Canceled");

            assertTrue(!customerDTOList.isEmpty());
        }catch(Exception e) {
            //	System.out.println(e);
            assertTrue(true);
        }
    }
}
