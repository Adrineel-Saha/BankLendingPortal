package com.cognizant.banklending.customermgmt.test.repositories;

import com.cognizant.banklending.customermgmt.entities.LoanAppDetailMaster;
import com.cognizant.banklending.customermgmt.entities.LoanApplication;
import com.cognizant.banklending.customermgmt.main.CustomerManagementModuleApplication;
import com.cognizant.banklending.customermgmt.repositories.LoanAppDetailMasterRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ContextConfiguration;

import java.util.Date;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertTrue;

@DataJpaTest
@ContextConfiguration(classes = CustomerManagementModuleApplication.class)
public class TestLoanAppDetailMasterRepository {
    @Autowired
    private LoanAppDetailMasterRepository loanAppDetailMasterRepository;
    @Autowired
    private TestEntityManager entityManager;

    @Test
    public void testFindAllPositive() {
        LoanAppDetailMaster loanAppDetailMaster=new LoanAppDetailMaster();
        loanAppDetailMaster.setId(1);
        loanAppDetailMaster.setMonthNo(1);
        loanAppDetailMaster.setInstallment(20000);
        loanAppDetailMaster.setInterestRate(5);
        loanAppDetailMaster.setPOutstandingBeginOfMonth(200000);
        loanAppDetailMaster.setPRepayment(15000);
        loanAppDetailMaster.setPrOutstandingEndOfMonth(185000);
        loanAppDetailMaster.setLastDateOfInstallPay(new Date(2022,1,31));

        LoanApplication loanApplication=new LoanApplication();

        loanApplication.setLoanAppId("LOAN001");
        loanApplication.setLoanAmt(200000);
        loanApplication.setNoOfYears(5);
        loanApplication.setPurpose("Home Renovation");
        loanApplication.setAppStatus("NewLoan");
        loanApplication.setTypeOfLoan("Home Loan");
        loanApplication.setLoanAppDate(new Date());
        loanApplication.setStatus("accepted");

        entityManager.persist(loanApplication);
        loanAppDetailMaster.setLoanApplication(loanApplication);

        entityManager.persist(loanAppDetailMaster);
        Iterable<LoanAppDetailMaster> loanAppDetailMasterIterable=loanAppDetailMasterRepository.findAll();
        assertTrue(loanAppDetailMasterIterable.iterator().hasNext());
    }
    @Test
    public void testFindAllNegative() {
        Iterable<LoanAppDetailMaster> loanAppDetailMasterIterable=loanAppDetailMasterRepository.findAll();
        assertTrue(!loanAppDetailMasterIterable.iterator().hasNext());
    }


    @Test
    public void testFindByIdPositive() {
        LoanAppDetailMaster loanAppDetailMaster=new LoanAppDetailMaster();
        loanAppDetailMaster.setId(2);
        loanAppDetailMaster.setMonthNo(2);
        loanAppDetailMaster.setInstallment(20000);
        loanAppDetailMaster.setInterestRate(5);
        loanAppDetailMaster.setPOutstandingBeginOfMonth(185000);
        loanAppDetailMaster.setPRepayment(15000);
        loanAppDetailMaster.setPrOutstandingEndOfMonth(170000);
        loanAppDetailMaster.setLastDateOfInstallPay(new Date(2022,2,28));

        LoanApplication loanApplication=new LoanApplication();

        loanApplication.setLoanAppId("LOAN001");
        loanApplication.setLoanAmt(200000);
        loanApplication.setNoOfYears(5);
        loanApplication.setPurpose("Home Renovation");
        loanApplication.setAppStatus("NewLoan");
        loanApplication.setTypeOfLoan("Home Loan");
        loanApplication.setLoanAppDate(new Date());
        loanApplication.setStatus("accepted");

        entityManager.persist(loanApplication);
        loanAppDetailMaster.setLoanApplication(loanApplication);

        entityManager.persist(loanAppDetailMaster);
        Optional<LoanAppDetailMaster> loanAppDetailMasterOptional=loanAppDetailMasterRepository.findById(2);
        assertTrue(loanAppDetailMasterOptional.isPresent());
    }

    @Test
    public void testFindByIdNegative() {
        Optional<LoanAppDetailMaster> loanAppDetailMasterOptional=loanAppDetailMasterRepository.findById(2);
        assertTrue(!loanAppDetailMasterOptional.isPresent());
    }

    @Test
    public void testSavePositive() {
        LoanAppDetailMaster loanAppDetailMaster=new LoanAppDetailMaster();
        loanAppDetailMaster.setId(3);
        loanAppDetailMaster.setMonthNo(1);
        loanAppDetailMaster.setInstallment(15000);
        loanAppDetailMaster.setInterestRate(4);
        loanAppDetailMaster.setPOutstandingBeginOfMonth(150000);
        loanAppDetailMaster.setPRepayment(10000);
        loanAppDetailMaster.setPrOutstandingEndOfMonth(140000);
        loanAppDetailMaster.setLastDateOfInstallPay(new Date(2022,1,31));

        LoanApplication loanApplication=new LoanApplication();

        loanApplication.setLoanAppId("LOAN002");
        loanApplication.setLoanAmt(150000);
        loanApplication.setNoOfYears(3);
        loanApplication.setPurpose("Car Purchase");
        loanApplication.setAppStatus("Approved");
        loanApplication.setTypeOfLoan("Auto Loan");
        loanApplication.setLoanAppDate(new Date());
        loanApplication.setStatus("no status");

        entityManager.persist(loanApplication);
        loanAppDetailMaster.setLoanApplication(loanApplication);

        loanAppDetailMasterRepository.save(loanAppDetailMaster);
        Optional<LoanAppDetailMaster> loanAppDetailMasterOptional=loanAppDetailMasterRepository.findById(3);
        assertTrue(loanAppDetailMasterOptional.isPresent());
    }

    @Test
    public void testSaveNegative() {
        Optional<LoanAppDetailMaster> loanAppDetailMasterOptional=loanAppDetailMasterRepository.findById(3);
        assertTrue(!loanAppDetailMasterOptional.isPresent());
    }

    @Test
    public void testDeletePositive() {
        LoanAppDetailMaster loanAppDetailMaster=new LoanAppDetailMaster();
        loanAppDetailMaster.setId(4);
        loanAppDetailMaster.setMonthNo(3);
        loanAppDetailMaster.setInstallment(15000);
        loanAppDetailMaster.setInterestRate(4);
        loanAppDetailMaster.setPOutstandingBeginOfMonth(140000);
        loanAppDetailMaster.setPRepayment(10000);
        loanAppDetailMaster.setPrOutstandingEndOfMonth(130000);
        loanAppDetailMaster.setLastDateOfInstallPay(new Date(2022,3,31));

        LoanApplication loanApplication=new LoanApplication();

        loanApplication.setLoanAppId("LOAN002");
        loanApplication.setLoanAmt(150000);
        loanApplication.setNoOfYears(3);
        loanApplication.setPurpose("Car Purchase");
        loanApplication.setAppStatus("Approved");
        loanApplication.setTypeOfLoan("Auto Loan");
        loanApplication.setLoanAppDate(new Date());
        loanApplication.setStatus("no status");

        entityManager.persist(loanApplication);

        loanAppDetailMaster.setLoanApplication(loanApplication);

        entityManager.persist(loanAppDetailMaster);

        loanAppDetailMasterRepository.delete(loanAppDetailMaster);
        Optional<LoanAppDetailMaster> loanAppDetailMasterOptional=loanAppDetailMasterRepository.findById(4);
        assertTrue(!loanAppDetailMasterOptional.isPresent());
    }

    @Test
    public void testDeleteNegative() {
        Optional<LoanAppDetailMaster> loanAppDetailMasterOptional=loanAppDetailMasterRepository.findById(4);
        assertTrue(!loanAppDetailMasterOptional.isPresent());
    }
}
