package com.cognizant.banklending.customermgmt.test.repositories;

import com.cognizant.banklending.customermgmt.entities.CustomerMaster;
import com.cognizant.banklending.customermgmt.main.CustomerManagementModuleApplication;
import com.cognizant.banklending.customermgmt.repositories.CustomerMasterRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ContextConfiguration;

import java.util.Date;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertTrue;

@DataJpaTest
@ContextConfiguration(classes = CustomerManagementModuleApplication.class)
public class TestCustomerMasterRepository {
    @Autowired
    private CustomerMasterRepository customerMasterRepository;
    @Autowired
    private TestEntityManager entityManager;

    @Test
    public void testFindAllPositive() {
        CustomerMaster customerMaster=new CustomerMaster();

        customerMaster.setCustId("CUST01");
        customerMaster.setCustFirstName("Adrineel");
        customerMaster.setCustLastName("Saha");
        customerMaster.setAddress("123 Street");
        customerMaster.setCity("Asansol");
        customerMaster.setContactNo(1234567890);
        customerMaster.setAdharCard(1456789012);
        customerMaster.setEmailId("adrineel.saha@cognizant.com");
        customerMaster.setBirthDate(new Date(2001,10,18));
        customerMaster.setMonthlySalary(65000);

        entityManager.persist(customerMaster);
        Iterable<CustomerMaster> customerMasterIterable=customerMasterRepository.findAll();
        assertTrue(customerMasterIterable.iterator().hasNext());
    }
    @Test
    public void testFindAllNegative() {
        Iterable<CustomerMaster> customerMasterIterable=customerMasterRepository.findAll();
        assertTrue(!customerMasterIterable.iterator().hasNext());
    }


    @Test
    public void testFindByIdPositive() {
        CustomerMaster customerMaster=new CustomerMaster();

        customerMaster.setCustId("CUST02");
        customerMaster.setCustFirstName("Arunabh");
        customerMaster.setCustLastName("Kalita");
        customerMaster.setAddress("456 Avenue");
        customerMaster.setCity("Dibrugarh");
        customerMaster.setContactNo(1876543210);
        customerMaster.setAdharCard(1567890123);
        customerMaster.setEmailId("arunabh.kalita@cognizant.com");
        customerMaster.setBirthDate(new Date(2000,5,15));
        customerMaster.setMonthlySalary(60000);

        entityManager.persist(customerMaster);
        Optional<CustomerMaster> customerMasterOptional =customerMasterRepository.findById("CUST02");
        assertTrue(customerMasterOptional.isPresent());
    }

    @Test
    public void testFindByIdNegative() {
        Optional<CustomerMaster> customerMasterOptional =customerMasterRepository.findById("CUST02");
        assertTrue(!customerMasterOptional.isPresent());
    }

    @Test
    public void testSavePositive() {
        CustomerMaster customerMaster=new CustomerMaster();

        customerMaster.setCustId("CUST03");
        customerMaster.setCustFirstName("Yash");
        customerMaster.setCustLastName("Biswakarma");
        customerMaster.setAddress("789 Boulevard");
        customerMaster.setCity("Darjeeling");
        customerMaster.setContactNo(1122334455);
        customerMaster.setAdharCard(1456701234);
        customerMaster.setEmailId("yash.biswakarma@cognizant.com");
        customerMaster.setBirthDate(new Date(2001,9,29));
        customerMaster.setMonthlySalary(55000);

        customerMasterRepository.save(customerMaster);
        Optional<CustomerMaster> customerMasterOptional =customerMasterRepository.findById("CUST03");
        assertTrue(customerMasterOptional.isPresent());
    }

    @Test
    public void testSaveNegative() {
        Optional<CustomerMaster> customerMasterOptional =customerMasterRepository.findById("CUST03");
        assertTrue(!customerMasterOptional.isPresent());
    }

    @Test
    public void testDeletePositive() {
        CustomerMaster customerMaster=new CustomerMaster();

        customerMaster.setCustId("CUST04");
        customerMaster.setCustFirstName("Sayan");
        customerMaster.setCustLastName("Kashyapi");
        customerMaster.setAddress("101 Road");
        customerMaster.setCity("Kolkata");
        customerMaster.setContactNo(1677889900);
        customerMaster.setAdharCard(1678901235);
        customerMaster.setEmailId("ayan.kashyapi@cognizant.com");
        customerMaster.setBirthDate(new Date(2002,5,19));
        customerMaster.setMonthlySalary(48000);

        customerMasterRepository.delete(customerMaster);
        Optional<CustomerMaster> customerMasterOptional =customerMasterRepository.findById("CUST04");
        assertTrue(!customerMasterOptional.isPresent());
    }

    @Test
    public void testDeleteNegative() {
        Optional<CustomerMaster> customerMasterOptional =customerMasterRepository.findById("CUST04");
        assertTrue(!customerMasterOptional.isPresent());
    }
}
