package com.cognizant.banklending.customermgmt.test.services;

import com.cognizant.banklending.customermgmt.dtos.ReducedPaymentDTO;
import com.cognizant.banklending.customermgmt.entities.LoanAppDetailMaster;
import com.cognizant.banklending.customermgmt.entities.LoanApplication;
import com.cognizant.banklending.customermgmt.repositories.LoanAppDetailMasterRepository;
import com.cognizant.banklending.customermgmt.services.ReducedPaymentServiceImpl;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.modelmapper.ModelMapper;

import java.util.Iterator;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class TestReducedPaymentServiceImpl {
    @Mock
    private LoanAppDetailMasterRepository loanAppDetailsMasterRepository;

    @Mock
    private ModelMapper modelMapper;

    @InjectMocks
    private ReducedPaymentServiceImpl reducedPaymentServiceImpl;

    @BeforeEach
    void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
    }

    @AfterEach
    void tearDown() throws Exception {

    }

    @Test
    public void testGetAllReducedPaymentsPositiveOneReducedPaymentFound() {
        try {
            List<LoanAppDetailMaster> listLoanAppDetailMasterMock=mock(List.class);
            when(loanAppDetailsMasterRepository.findByLoanApplicationLoanAppId(Mockito.anyString())).thenReturn(listLoanAppDetailMasterMock);

            Iterator<LoanAppDetailMaster> iteratorLoanAppDetailMasterMock =mock(Iterator.class);

            when(listLoanAppDetailMasterMock.iterator()).thenReturn(iteratorLoanAppDetailMasterMock);
            when(iteratorLoanAppDetailMasterMock.hasNext()).thenReturn(true).thenReturn(false);

            LoanAppDetailMaster loanAppDetailMasterMock=mock(LoanAppDetailMaster.class);

            when(iteratorLoanAppDetailMasterMock.next()).thenReturn(loanAppDetailMasterMock);

            ReducedPaymentDTO reducedPaymentDTOMock=mock(ReducedPaymentDTO.class);

            when(modelMapper.map(Mockito.any(LoanAppDetailMaster.class), Mockito.eq(ReducedPaymentDTO.class))).thenReturn(reducedPaymentDTOMock);

            LoanApplication loanApplicationMock=mock(LoanApplication.class);
            when(loanAppDetailMasterMock.getLoanApplication()).thenReturn(loanApplicationMock);

            List<ReducedPaymentDTO> reducedPaymentDTOList =reducedPaymentServiceImpl.getAllReducedPayments("LOAN001");
//            System.out.println(customerDTOList.size());
            assertTrue(reducedPaymentDTOList.size()==1);
        }catch(Exception e) {
//            System.out.println(e);
            assertTrue(false);
        }
    }

    @Test
    public void testGetAllReducedPaymentsPositiveMultipleReducedPaymentsFound() {
        try {
            List<LoanAppDetailMaster> listLoanAppDetailMasterMock=mock(List.class);
            when(loanAppDetailsMasterRepository.findByLoanApplicationLoanAppId(Mockito.anyString())).thenReturn(listLoanAppDetailMasterMock);

            Iterator<LoanAppDetailMaster> iteratorLoanAppDetailMasterMock =mock(Iterator.class);

            when(listLoanAppDetailMasterMock.iterator()).thenReturn(iteratorLoanAppDetailMasterMock);
            when(iteratorLoanAppDetailMasterMock.hasNext()).thenReturn(true).thenReturn(true).thenReturn(false);

            LoanAppDetailMaster loanAppDetailMasterMock=mock(LoanAppDetailMaster.class);

            when(iteratorLoanAppDetailMasterMock.next()).thenReturn(loanAppDetailMasterMock);

            ReducedPaymentDTO reducedPaymentDTOMock=mock(ReducedPaymentDTO.class);

            when(modelMapper.map(Mockito.any(LoanAppDetailMaster.class), Mockito.eq(ReducedPaymentDTO.class))).thenReturn(reducedPaymentDTOMock);

            LoanApplication loanApplicationMock=mock(LoanApplication.class);
            when(loanAppDetailMasterMock.getLoanApplication()).thenReturn(loanApplicationMock);

            List<ReducedPaymentDTO> reducedPaymentDTOList =reducedPaymentServiceImpl.getAllReducedPayments("LOAN001");
//            System.out.println(customerDTOList.size());
            assertTrue(reducedPaymentDTOList.size()>1);
        }catch(Exception e) {
//            System.out.println(e);
            assertTrue(false);
        }
    }

    @Test
    public void testGetAllReducedPaymentsException() {
        try {
            List<LoanAppDetailMaster> listLoanAppDetailMasterMock=mock(List.class);
            when(loanAppDetailsMasterRepository.findByLoanApplicationLoanAppId(Mockito.anyString())).thenReturn(listLoanAppDetailMasterMock);

            Iterator<LoanAppDetailMaster> iteratorLoanAppDetailMasterMock =mock(Iterator.class);

            when(listLoanAppDetailMasterMock.iterator()).thenReturn(iteratorLoanAppDetailMasterMock);
            when(iteratorLoanAppDetailMasterMock.hasNext()).thenReturn(false);

            LoanAppDetailMaster loanAppDetailMasterMock=mock(LoanAppDetailMaster.class);

            when(iteratorLoanAppDetailMasterMock.next()).thenReturn(loanAppDetailMasterMock);

            ReducedPaymentDTO reducedPaymentDTOMock=mock(ReducedPaymentDTO.class);

            when(modelMapper.map(Mockito.any(LoanAppDetailMaster.class), Mockito.eq(ReducedPaymentDTO.class))).thenReturn(reducedPaymentDTOMock);

            LoanApplication loanApplicationMock=mock(LoanApplication.class);
            when(loanAppDetailMasterMock.getLoanApplication()).thenReturn(loanApplicationMock);

            List<ReducedPaymentDTO> reducedPaymentDTOList =reducedPaymentServiceImpl.getAllReducedPayments("LOAN001");
//            System.out.println(customerDTOList.size());
            assertTrue(!reducedPaymentDTOList.isEmpty());
        }catch(Exception e) {
//            System.out.println(e);
            assertTrue(true);
        }
    }
}
