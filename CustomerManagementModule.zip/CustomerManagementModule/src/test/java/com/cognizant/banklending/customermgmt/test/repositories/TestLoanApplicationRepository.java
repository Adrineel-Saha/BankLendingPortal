package com.cognizant.banklending.customermgmt.test.repositories;

import com.cognizant.banklending.customermgmt.entities.CustomerMaster;
import com.cognizant.banklending.customermgmt.entities.LoanApplication;
import com.cognizant.banklending.customermgmt.main.CustomerManagementModuleApplication;
import com.cognizant.banklending.customermgmt.repositories.LoanApplicationRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ContextConfiguration;

import java.util.Date;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertTrue;

@DataJpaTest
@ContextConfiguration(classes = CustomerManagementModuleApplication.class)
public class TestLoanApplicationRepository {
    @Autowired
    private LoanApplicationRepository loanApplicationRepository;
    @Autowired
    private TestEntityManager entityManager;

    @Test
    public void testFindAllPositive() {
        LoanApplication loanApplication=new LoanApplication();

        loanApplication.setLoanAppId("LOAN001");
        loanApplication.setLoanAmt(200000);
        loanApplication.setNoOfYears(5);
        loanApplication.setPurpose("Home Renovation");
        loanApplication.setAppStatus("NewLoan");
        loanApplication.setTypeOfLoan("Home Loan");
        loanApplication.setLoanAppDate(new Date());
        loanApplication.setStatus("accepted");

        CustomerMaster customerMaster=new CustomerMaster();

        customerMaster.setCustId("CUST01");
        customerMaster.setCustFirstName("Adrineel");
        customerMaster.setCustLastName("Saha");
        customerMaster.setAddress("123 Street");
        customerMaster.setCity("Asansol");
        customerMaster.setContactNo(1234567890);
        customerMaster.setAdharCard(1456789012);
        customerMaster.setEmailId("adrineel.saha@cognizant.com");
        customerMaster.setBirthDate(new Date(2001,10,18));
        customerMaster.setMonthlySalary(65000);

        entityManager.persist(customerMaster);

        loanApplication.setCustomerMaster(customerMaster);

        entityManager.persist(loanApplication);
        Iterable<LoanApplication> loanApplicationIterable=loanApplicationRepository.findAll();
        assertTrue(loanApplicationIterable.iterator().hasNext());
    }
    @Test
    public void testFindAllNegative() {
        Iterable<LoanApplication> loanApplicationIterable=loanApplicationRepository.findAll();
        assertTrue(!loanApplicationIterable.iterator().hasNext());
    }


    @Test
    public void testFindByIdPositive() {
        LoanApplication loanApplication=new LoanApplication();

        loanApplication.setLoanAppId("LOAN002");
        loanApplication.setLoanAmt(150000);
        loanApplication.setNoOfYears(3);
        loanApplication.setPurpose("Car Purchase");
        loanApplication.setAppStatus("Approved");
        loanApplication.setTypeOfLoan("Auto Loan");
        loanApplication.setLoanAppDate(new Date());
        loanApplication.setStatus("no status");

        CustomerMaster customerMaster=new CustomerMaster();

        customerMaster.setCustId("CUST02");
        customerMaster.setCustFirstName("Arunabh");
        customerMaster.setCustLastName("Kalita");
        customerMaster.setAddress("456 Avenue");
        customerMaster.setCity("Dibrugarh");
        customerMaster.setContactNo(1876543210);
        customerMaster.setAdharCard(1567890123);
        customerMaster.setEmailId("arunabh.kalita@cognizant.com");
        customerMaster.setBirthDate(new Date(2000,5,15));
        customerMaster.setMonthlySalary(60000);

        entityManager.persist(customerMaster);

        loanApplication.setCustomerMaster(customerMaster);

        entityManager.persist(loanApplication);
        Optional<LoanApplication> loanApplicationOptional=loanApplicationRepository.findById("LOAN002");
        assertTrue(loanApplicationOptional.isPresent());
    }

    @Test
    public void testFindByIdNegative() {
        Optional<LoanApplication> loanApplicationOptional=loanApplicationRepository.findById("LOAN002");
        assertTrue(!loanApplicationOptional.isPresent());
    }

    @Test
    public void testSavePositive() {
        LoanApplication loanApplication=new LoanApplication();

        loanApplication.setLoanAppId("LOAN003");
        loanApplication.setLoanAmt(250000);
        loanApplication.setNoOfYears(7);
        loanApplication.setPurpose("Business Expansion");
        loanApplication.setAppStatus("Sanctioned");
        loanApplication.setTypeOfLoan("Business Loan");
        loanApplication.setLoanAppDate(new Date());
        loanApplication.setStatus("rejected");

        CustomerMaster customerMaster=new CustomerMaster();

        customerMaster.setCustId("CUST03");
        customerMaster.setCustFirstName("Yash");
        customerMaster.setCustLastName("Biswakarma");
        customerMaster.setAddress("789 Boulevard");
        customerMaster.setCity("Darjeeling");
        customerMaster.setContactNo(1122334455);
        customerMaster.setAdharCard(1456701234);
        customerMaster.setEmailId("yash.biswakarma@cognizant.com");
        customerMaster.setBirthDate(new Date(2001,9,29));
        customerMaster.setMonthlySalary(55000);

        entityManager.persist(customerMaster);
        loanApplication.setCustomerMaster(customerMaster);

        loanApplicationRepository.save(loanApplication);
        Optional<LoanApplication> loanApplicationOptional=loanApplicationRepository.findById("LOAN003");
        assertTrue(loanApplicationOptional.isPresent());
    }

    @Test
    public void testSaveNegative() {
        Optional<LoanApplication> loanApplicationOptional=loanApplicationRepository.findById("LOAN003");
        assertTrue(!loanApplicationOptional.isPresent());
    }

    @Test
    public void testDeletePositive() {
        LoanApplication loanApplication=new LoanApplication();

        loanApplication.setLoanAppId("LOAN004");
        loanApplication.setLoanAmt(100000);
        loanApplication.setNoOfYears(2);
        loanApplication.setPurpose("Education");
        loanApplication.setAppStatus("NewLoan");
        loanApplication.setTypeOfLoan("Education Loan");
        loanApplication.setLoanAppDate(new Date());
        loanApplication.setStatus("accepted'");

        CustomerMaster customerMaster=new CustomerMaster();

        customerMaster.setCustId("CUST04");
        customerMaster.setCustFirstName("Sayan");
        customerMaster.setCustLastName("Kashyapi");
        customerMaster.setAddress("101 Road");
        customerMaster.setCity("Kolkata");
        customerMaster.setContactNo(1677889900);
        customerMaster.setAdharCard(1678901235);
        customerMaster.setEmailId("ayan.kashyapi@cognizant.com");
        customerMaster.setBirthDate(new Date(2002,5,19));
        customerMaster.setMonthlySalary(48000);

        entityManager.persist(customerMaster);

        loanApplication.setCustomerMaster(customerMaster);

        entityManager.persist(loanApplication);

        loanApplicationRepository.delete(loanApplication);
        Optional<LoanApplication> loanApplicationOptional=loanApplicationRepository.findById("LOAN004");
        assertTrue(!loanApplicationOptional.isPresent());
    }

    @Test
    public void testDeleteNegative() {
        Optional<LoanApplication> loanApplicationOptional=loanApplicationRepository.findById("LOAN004");
        assertTrue(!loanApplicationOptional.isPresent());
    }
}
