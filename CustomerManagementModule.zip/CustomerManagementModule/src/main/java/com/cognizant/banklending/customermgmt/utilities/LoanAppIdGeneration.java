package com.cognizant.banklending.customermgmt.utilities;

import java.util.Random;

public class LoanAppIdGeneration {
    public static String generateLoanAppId(String typeOfLoan) {
        String formattedLastName= typeOfLoan.substring(0,Math.min(2, typeOfLoan.length())).toUpperCase();
        int randomNumber=new Random().nextInt(9000)+1000;
        String formattedNumber=String.valueOf(randomNumber);
        return formattedLastName+formattedNumber;
    }
}
