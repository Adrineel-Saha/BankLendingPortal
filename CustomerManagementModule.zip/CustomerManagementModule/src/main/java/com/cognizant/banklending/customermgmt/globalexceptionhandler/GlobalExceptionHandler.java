package com.cognizant.banklending.customermgmt.globalexceptionhandler;

import com.cognizant.banklending.customermgmt.exceptions.DuplicateAccountException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.resource.NoResourceFoundException;

@ControllerAdvice
public class GlobalExceptionHandler {
    @ExceptionHandler(value = NoResourceFoundException.class)
    public ResponseEntity<String> handleNoResourceFoundException(NoResourceFoundException e) {
        ResponseEntity<String> errorResponse = new ResponseEntity<String>(e.getMessage(), HttpStatus.NOT_FOUND);
        return errorResponse;
    }

    @ExceptionHandler(value = DuplicateAccountException.class)
    public ResponseEntity<String> handleDuplicateAccountException(DuplicateAccountException e) {
        ResponseEntity<String> errorResponse = new ResponseEntity<String>(e.getMessage(), HttpStatus.CONFLICT);
        return errorResponse;
    }

    @ExceptionHandler(value = Exception.class)
    public ResponseEntity<String> exceptionHandler(Exception e) {
        ResponseEntity<String> errorResponse = new ResponseEntity<String>(e.getMessage(), HttpStatus.BAD_REQUEST);
        return errorResponse;
    }
}
