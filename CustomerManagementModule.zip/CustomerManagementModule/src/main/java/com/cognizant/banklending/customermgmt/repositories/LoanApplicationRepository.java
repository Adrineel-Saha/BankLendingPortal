package com.cognizant.banklending.customermgmt.repositories;

import com.cognizant.banklending.customermgmt.entities.LoanApplication;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

@Repository
public interface LoanApplicationRepository extends JpaRepository<LoanApplication,String> {
    List<LoanApplication> findByLoanAppDate(Date date);
    List<LoanApplication> findByAppStatus(String status);
}
