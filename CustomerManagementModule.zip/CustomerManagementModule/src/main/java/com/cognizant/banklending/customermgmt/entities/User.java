package com.cognizant.banklending.customermgmt.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name="Users")
public class User {
    @Id
    @Column(name="User_Name")
    private String userName;

    @Column(name="Password")
    private String password;

    @Column(name="Role")
    private String role;

    @Column(name="Is_Account_Locked")
    private boolean isAccountLocked;
}
