package com.cognizant.banklending.customermgmt.repositories;

import com.cognizant.banklending.customermgmt.entities.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User,String> {
}
