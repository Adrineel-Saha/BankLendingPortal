package com.cognizant.banklending.customermgmt.main;

import org.modelmapper.ModelMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication(scanBasePackages = "com.cognizant.banklending.customermgmt.*")
@EnableJpaRepositories(basePackages = "com.cognizant.banklending.customermgmt.repositories")
@EntityScan(basePackages = "com.cognizant.banklending.customermgmt.entities")
@EnableDiscoveryClient(autoRegister=true)
public class CustomerManagementModuleApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomerManagementModuleApplication.class, args);
	}

	@Bean
	public ModelMapper modelMapper()
	{
		return new ModelMapper();
	}
}
