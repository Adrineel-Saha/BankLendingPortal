package com.cognizant.banklending.customermgmt.services;

import com.cognizant.banklending.customermgmt.dtos.UserDTO;
import com.cognizant.banklending.customermgmt.entities.User;

import java.util.List;

public interface UserService {
    public List<User> listOfUsers();
    public UserDTO authenticateUser(String username, String password);
}
