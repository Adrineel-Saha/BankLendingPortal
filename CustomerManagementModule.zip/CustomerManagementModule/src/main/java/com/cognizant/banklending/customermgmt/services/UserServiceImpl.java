package com.cognizant.banklending.customermgmt.services;

import com.cognizant.banklending.customermgmt.dtos.UserDTO;
import com.cognizant.banklending.customermgmt.entities.User;
import com.cognizant.banklending.customermgmt.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService{
    @Autowired
    private UserRepository userRepository;

    @Override
    public List<User> listOfUsers() {
        return userRepository.findAll();
    }

    @Override
    public UserDTO authenticateUser(String username, String password) {
        List<User> users= listOfUsers();
        UserDTO userDTO=new UserDTO();
        for(User user:users) {
//			System.out.println(user);
            if(user.getUserName().equals(username) && user.getPassword().equals(password) && !user.isAccountLocked()) {
//				System.out.println(user);
                userDTO.setUserName(user.getUserName());
                userDTO.setPassword(user.getPassword());
                userDTO.setRole(user.getRole());
                userDTO.setAccountLocked(user.isAccountLocked());
                break;
            }
        }
//		System.out.println(userDTO);
        return userDTO;
    }
}
