package com.cognizant.banklending.customermgmt.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Entity
@Table(name="Loan_App_Detail_Master")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LoanAppDetailMaster {
    @Id
    @Column(name="Id")
    private int Id;

    @Column(name="Month_No")
    private int monthNo;

    @Column(name="Installment")
    private int installment;

    @Column(name="Interest_Rate")
    private int interestRate;

    @Column(name="P_Outstanding_Begin_Of_Month")
    private int pOutstandingBeginOfMonth;

    @Column(name="P_Repayment")
    private int pRepayment;

    @Column(name="Pr_Outstanding_End_Of_Month")
    private int prOutstandingEndOfMonth;

    @Column(name="Last_Date_Of_Install_Pay")
    @Temporal(TemporalType.DATE)
    private Date lastDateOfInstallPay;

    @ManyToOne
    @JoinColumn(name="Loan_App_Id",referencedColumnName="Loan_App_Id")
    private LoanApplication loanApplication;
}
