package com.cognizant.banklending.customermgmt.services;

import com.cognizant.banklending.customermgmt.dtos.ReducedPaymentDTO;

import java.util.List;

public interface ReducedPaymentService {
    public List<ReducedPaymentDTO> getAllReducedPayments(String loanAppId);
}
