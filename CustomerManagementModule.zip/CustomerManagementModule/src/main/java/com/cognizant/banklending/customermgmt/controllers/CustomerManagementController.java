package com.cognizant.banklending.customermgmt.controllers;

import com.cognizant.banklending.customermgmt.dtos.CustomerDTO;
import com.cognizant.banklending.customermgmt.dtos.LoanAppDTO;
import com.cognizant.banklending.customermgmt.dtos.ReducedPaymentDTO;
import com.cognizant.banklending.customermgmt.services.CustomerMasterService;
import com.cognizant.banklending.customermgmt.services.LoanApplicationService;
import com.cognizant.banklending.customermgmt.services.ReducedPaymentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

@Slf4j
@RestController
@RequestMapping("api")
@CrossOrigin(origins = "http://localhost:4200")
@Tag(name="CustomerManagement",description = "CustomerManagement REST API")
public class CustomerManagementController {
    @Autowired
    private CustomerMasterService customerMasterService;

    @Autowired
    private LoanApplicationService loanApplicationService;

    @Autowired
    private ReducedPaymentService reducedPaymentService;

    @PostMapping("customers/new")
    @Operation(summary="Create a Customer",description="Creates a new customer")
    public ResponseEntity<CustomerDTO> addCustomer(@RequestBody CustomerDTO customerDTO){
        log.info("Adding a new customer: " + customerDTO);

        CustomerDTO newCustomerDTO=customerMasterService.addCustomer(customerDTO);
        if(newCustomerDTO!=null){
            return new ResponseEntity<>(newCustomerDTO, HttpStatus.CREATED);
        }
        else{
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("customers")
    @Operation(summary="Get all Customers",description="Retrieve a list of all customers")
    public ResponseEntity<List<CustomerDTO>> getAllCustomers(){
        log.info("Getting all Customers");

        List<CustomerDTO> customerDTOList=customerMasterService.getAllCustomers();
        if(customerDTOList!=null && !customerDTOList.isEmpty()){
            return new ResponseEntity<>(customerDTOList, HttpStatus.OK);
        }
        else{
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("customers/{custId}")
    @Operation(summary="Get Customer by Id",description="Retrieve a customer by Customer_Id")
    public ResponseEntity<CustomerDTO> getCustomerById(@PathVariable String custId){
        log.info("Getting a Customer by Id: " + custId);

        CustomerDTO existingCustomerDTO=customerMasterService.getCustomerById(custId);
        if(existingCustomerDTO!=null){
            return new ResponseEntity<>(existingCustomerDTO, HttpStatus.OK);
        }
        else{
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

    @PutMapping("customers/{custId}/update")
    @Operation(summary="Update a Customer",description="Updates an existing customer")
    public ResponseEntity<CustomerDTO> updateCustomer(@PathVariable String custId,@RequestBody CustomerDTO customerDTO){
        log.info("Updating customer " + customerDTO + " with Customer_Id: " + custId);

        CustomerDTO updatedCustomerDTO =customerMasterService.updateCustomer(custId,customerDTO);
        if(updatedCustomerDTO !=null){
            return new ResponseEntity<>(updatedCustomerDTO, HttpStatus.ACCEPTED);
        }
        else{
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping(value="customers/loan/{status:NewLoan|Canceled|Approved|Sanctioned}" , headers = "Request-Type=Status")
    @Operation(summary="Get all Customers by Status",description="Retrieve a list of all customers by App_Status")
    public ResponseEntity<List<CustomerDTO>> getAllCustomersByStatus(@PathVariable("status") String status){
        log.info("Getting all Customers by Status: " + status);

        List<CustomerDTO> customerDTOList=customerMasterService.getAllCustomersByStatus(status);
        if(customerDTOList!=null && !customerDTOList.isEmpty()){
            return new ResponseEntity<>(customerDTOList, HttpStatus.OK);
        }
        else{
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("customers/loan/{date:\\d{4}-\\d{2}-\\d{2}}")
    @Operation(summary="Get all Loan_Applications by Date",description="Retrieve a list of all loan records by Loan_App_Date")
    public ResponseEntity<List<LoanAppDTO>> getAllLoanApplicationsByDate(@PathVariable("date") @DateTimeFormat(pattern = "yyyy-MM-dd") Date date){
        log.info("Getting all Loan Records by Date: " + date);

        List<LoanAppDTO> loanAppDTOList=loanApplicationService.getAllLoanApplicationsByDate(date);
        if(loanAppDTOList!=null && !loanAppDTOList.isEmpty()){
            return new ResponseEntity<>(loanAppDTOList, HttpStatus.OK);
        }
        else{
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

    @PutMapping("customers/loan/{loanAppId}/update")
    @Operation(summary="Update a Loan_Application",description="Updates an existing loan record")
    public ResponseEntity<LoanAppDTO> updateLoanApplication(@PathVariable String loanAppId,@RequestBody LoanAppDTO loanAppDTO){
        log.info("Updating loan record " + loanAppDTO + " with Loan_App_Id: " + loanAppId);

        LoanAppDTO updatedLoanAppDTO=loanApplicationService.updateLoanApplication(loanAppId,loanAppDTO);
        if(updatedLoanAppDTO !=null){
            return new ResponseEntity<>(updatedLoanAppDTO, HttpStatus.ACCEPTED);
        }
        else{
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping(value="customers/loan/{loanAppId:[a-zA-Z0-9-]+}" , headers = "Request-Type=LoanAppId")
    @Operation(summary="Get Loan_Application By Id",description="Retrieve a loan record by Loan_App_Id")
    public ResponseEntity<LoanAppDTO> getLoanApplicationById(@PathVariable("loanAppId") String loanAppId){
        log.info("Getting a Loan Record by Id: " + loanAppId);

        LoanAppDTO existingLoanAppDTO =loanApplicationService.getLoanApplicationById(loanAppId);
        if(existingLoanAppDTO !=null){
            return new ResponseEntity<>(existingLoanAppDTO, HttpStatus.OK);
        }
        else{
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("customers/loan/checkCustomerAcceptanceStatus/{loanAppId}")
    @Operation(summary="Get a Loan_Application by Status",description="Retrieve a loan record by Status")
    public ResponseEntity<LoanAppDTO> getLoanApplicationByStatus(@PathVariable String loanAppId){
        log.info("Getting a Loan Record by Status");

        LoanAppDTO existingLoanAppDTO =loanApplicationService.getLoanApplicationByStatus(loanAppId);
        if(existingLoanAppDTO !=null){
            return new ResponseEntity<>(existingLoanAppDTO, HttpStatus.OK);
        }
        else{
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("customers/loan/new")
    @Operation(summary="Create a Loan_Application",description="Creates a new loan record")
    public ResponseEntity<LoanAppDTO>addLoanApplication(@RequestBody LoanAppDTO loanAppDTO){
        log.info("Adding a new Loan Record: " + loanAppDTO);

        LoanAppDTO newloanAppDTO=loanApplicationService.addLoanApplication(loanAppDTO);
        if(newloanAppDTO!=null){
            return new ResponseEntity<>(newloanAppDTO, HttpStatus.CREATED);
        }
        else{
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("loanApps/receiveSanctionAmount/{loanAppId}")
    @Operation(summary="Get all Reduced_Payments",description="Retrieve a list of all reduced payments by Loan_App_Id")
    public ResponseEntity<List<ReducedPaymentDTO>> getAllReducedPayments(@PathVariable String loanAppId){
        log.info("Getting all Reduced Payments by Loan_App_id: " + loanAppId);

        List<ReducedPaymentDTO> reducedPaymentDTOlist =reducedPaymentService.getAllReducedPayments(loanAppId);
        if(reducedPaymentDTOlist !=null && !reducedPaymentDTOlist.isEmpty()){
            return new ResponseEntity<>(reducedPaymentDTOlist, HttpStatus.OK);
        }
        else{
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }
}
