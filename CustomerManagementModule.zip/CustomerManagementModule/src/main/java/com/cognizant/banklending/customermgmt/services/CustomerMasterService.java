package com.cognizant.banklending.customermgmt.services;

import com.cognizant.banklending.customermgmt.dtos.CustomerDTO;

import java.util.List;

public interface CustomerMasterService {
    public CustomerDTO addCustomer(CustomerDTO customerDTO);
    public List<CustomerDTO> getAllCustomers();
    public CustomerDTO getCustomerById(String custId);
    public CustomerDTO updateCustomer(String custId,CustomerDTO customerDTO);
    public List<CustomerDTO> getAllCustomersByStatus(String status);
}
