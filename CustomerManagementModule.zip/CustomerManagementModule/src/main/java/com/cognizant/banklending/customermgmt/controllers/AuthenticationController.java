package com.cognizant.banklending.customermgmt.controllers;

import com.cognizant.banklending.customermgmt.dtos.UserDTO;
import com.cognizant.banklending.customermgmt.dtos.UserRequestDTO;
import com.cognizant.banklending.customermgmt.services.UserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequestMapping("authenticate")
@CrossOrigin(origins = "http://localhost:4200")
@Tag(name="Authentication",description = "Authentication REST API")
public class AuthenticationController {
    @Autowired
    private UserService userService;

    @PostMapping("users")
    @Operation(summary="Check Authenticated User",description="Checks whether an user is authenticated")
    public ResponseEntity<UserDTO> authenticate(@RequestBody UserRequestDTO userRequestDTO){
        log.info("Authenticating an user: " + userRequestDTO);

        UserDTO userDTO=userService.authenticateUser(userRequestDTO.getUserName(), userRequestDTO.getPassword());
        if(userDTO.getUserName()!=null) {
            return new ResponseEntity<>(userDTO, HttpStatus.ACCEPTED);
        }else {
            return new ResponseEntity<>(HttpStatus.FORBIDDEN);
        }
    }
}
