package com.cognizant.banklending.customermgmt.repositories;

import com.cognizant.banklending.customermgmt.entities.CustomerMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface CustomerMasterRepository extends JpaRepository<CustomerMaster,String> {
    Optional<CustomerMaster> findByAdharCard(int adharCard);
}
