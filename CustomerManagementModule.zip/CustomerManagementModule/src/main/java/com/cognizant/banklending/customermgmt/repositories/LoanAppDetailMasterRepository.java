package com.cognizant.banklending.customermgmt.repositories;

import com.cognizant.banklending.customermgmt.entities.LoanAppDetailMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LoanAppDetailMasterRepository extends JpaRepository<LoanAppDetailMaster,Integer> {
    List<LoanAppDetailMaster> findByLoanApplicationLoanAppId(String loanAppId);
}
