package com.cognizant.banklending.customermgmt.services;

import com.cognizant.banklending.customermgmt.dtos.LoanAppDTO;

import java.util.Date;
import java.util.List;

public interface LoanApplicationService {
    public List<LoanAppDTO> getAllLoanApplicationsByDate(Date date);
    public LoanAppDTO updateLoanApplication(String loanAppId, LoanAppDTO loanAppDTO);
    public LoanAppDTO getLoanApplicationById(String loanAppId);
    public LoanAppDTO getLoanApplicationByStatus(String loanAppId);
    public LoanAppDTO addLoanApplication(LoanAppDTO loanAppDTO);
}
