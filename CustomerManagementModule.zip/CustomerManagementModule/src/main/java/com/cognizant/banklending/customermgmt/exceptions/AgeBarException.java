package com.cognizant.banklending.customermgmt.exceptions;

public class AgeBarException extends RuntimeException{
    public AgeBarException(String message){
        super(message);
    }
}
