package com.cognizant.banklending.customermgmt.utilities;

import com.cognizant.banklending.customermgmt.dtos.CustomerDTO;
import com.cognizant.banklending.customermgmt.exceptions.AgeBarException;
import com.cognizant.banklending.customermgmt.exceptions.DuplicateAccountException;
import com.cognizant.banklending.customermgmt.repositories.CustomerMasterRepository;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.Period;
import java.time.ZoneId;
import java.util.Date;
import java.util.Set;

public class CustomerMasterValidation {
//    @Autowired
    public CustomerMasterRepository customerMasterRepository;

//    @Autowired
//    public CustomerMasterValidation(CustomerMasterRepository customerMasterRepository){
//        this.customerMasterRepository=customerMasterRepository;
//    }

    public  void validateCustomerMaster(CustomerDTO customerDTO, CustomerMasterRepository customerMasterRepository) {
        Validator validator= Validation.buildDefaultValidatorFactory().getValidator();
        Set<ConstraintViolation<CustomerDTO>> violations=validator.validate(customerDTO);

        if(!violations.isEmpty()) {
            throw new ConstraintViolationException(violations);
        }

        if(String.valueOf(customerDTO.getContactNo()).length()!=10) {
            throw new IllegalArgumentException("Phone number should be exactly 10 digits long");
        }

        if(!customerDTO.getEmailId().endsWith("@cognizant.com")) {
            throw new IllegalArgumentException("Email address should always have @cognizant.com");
        }

        if(!customerDTO.getCustFirstName().matches("[a-zA-Z]+") || !customerDTO.getCustLastName().matches("[a-zA-Z]+")||
                customerDTO.getCustFirstName().length()<3 || customerDTO.getCustLastName().length()<3) {
            throw new IllegalArgumentException("Invalid first name or last name");
        }

        if(customerMasterRepository.findByAdharCard(customerDTO.getAdharCard()).isPresent()){
            throw new DuplicateAccountException("User already present with Adhar Id: " + customerDTO.getAdharCard());
        }

        int age= Period.between(customerDTO.getBirthDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate(), new Date().toInstant().atZone(ZoneId.systemDefault()).toLocalDate()).getYears();

        if(age<18 || age>58){
            throw new AgeBarException("Age should be between 18 and 58");
        }

        if(customerDTO.getMonthlySalary()<=0){
            throw new IllegalArgumentException("Salary should be greater than zero");
        }

    }
}
