package com.cognizant.banklending.customermgmt.utilities;

import com.cognizant.banklending.customermgmt.dtos.LoanAppDTO;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import jakarta.validation.Validation;
import jakarta.validation.Validator;

import java.util.Set;

public class LoanApplicationValidation {
    public  void validateLoanApplication(LoanAppDTO loanAppDTO){
        Validator validator= Validation.buildDefaultValidatorFactory().getValidator();
        Set<ConstraintViolation<LoanAppDTO>> violations=validator.validate(loanAppDTO);

        if(!violations.isEmpty()) {
            throw new ConstraintViolationException(violations);
        }

        if(loanAppDTO.getLoanAmt()<=0){
            throw new IllegalArgumentException("Amount should be positive");
        }

//        if(!loanAppDTO.getAppStatus().equals("NewLoan")){
//            throw new LoanUnderProcessingExcepttion("Customer can't update loan record");
//        }

        if(loanAppDTO.getNoOfYears()<=0){
            throw new IllegalArgumentException("No of years should be positive");
        }
    }
}
