package com.cognizant.banklending.customermgmt.services;

import com.cognizant.banklending.customermgmt.dtos.ReducedPaymentDTO;
import com.cognizant.banklending.customermgmt.entities.LoanAppDetailMaster;
import com.cognizant.banklending.customermgmt.repositories.LoanAppDetailMasterRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Service
public class ReducedPaymentServiceImpl implements ReducedPaymentService{
    @Autowired
    private LoanAppDetailMasterRepository loanAppDetailMasterRepository;
    @Autowired
    private ModelMapper modelMapper;

    @Override
    public List<ReducedPaymentDTO> getAllReducedPayments(String loanAppId) {
        List<LoanAppDetailMaster> loanAppDetailMasterList=loanAppDetailMasterRepository.findByLoanApplicationLoanAppId(loanAppId);

        Iterator<LoanAppDetailMaster> loanAppDetailMasterIterator=loanAppDetailMasterList.iterator();
        List<ReducedPaymentDTO> reducedPaymentDTOList=new ArrayList<>();

        while(loanAppDetailMasterIterator.hasNext()){
            LoanAppDetailMaster loanAppDetailMaster=loanAppDetailMasterIterator.next();
            ReducedPaymentDTO reducedPaymentDTO=modelMapper.map(loanAppDetailMaster,ReducedPaymentDTO.class);
            modelMapper.map(loanAppDetailMaster.getLoanApplication(),reducedPaymentDTO);

            double baseReduction = 0.90; // Base 10% reduction
            double interestFactor = loanAppDetailMaster.getInterestRate() / 100.0;
            double amountFactor = loanAppDetailMaster.getLoanApplication().getLoanAmt() > 500000 ? 0.95 : 1.00; // Extra 5% reduction for amounts > 500,000
            double yearFactor = loanAppDetailMaster.getLoanApplication().getNoOfYears() > 10 ? 0.97 : 1.00; // Extra 3% reduction for loans > 10 years
            double repaymentFactor =  loanAppDetailMaster.getPRepayment() > 10000 ? 0.98 : 1.00; // Extra 2% reduction for repayments > 10,000
            double reductionFactor = baseReduction * interestFactor * amountFactor * yearFactor * repaymentFactor;
            int originalInstallment = loanAppDetailMaster.getInstallment();

            int reducedPayment=(int) (originalInstallment * reductionFactor);

            reducedPaymentDTO.setReducedPayment(reducedPayment);
            reducedPaymentDTOList.add(reducedPaymentDTO);
        }

        if(reducedPaymentDTOList.isEmpty()) {
            throw new RuntimeException("List is empty");
        }

        return reducedPaymentDTOList;
    }
}
