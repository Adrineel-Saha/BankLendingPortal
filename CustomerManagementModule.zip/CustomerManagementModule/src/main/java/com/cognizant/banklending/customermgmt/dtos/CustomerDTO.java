package com.cognizant.banklending.customermgmt.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CustomerDTO {
//    @JsonIgnore
    @Length(min=6,max=6)
    private String custId;

    @Length(min=3)
    private String custFirstName;

    @Length(min=3)
    private String custLastName;

    private String address;

    private String city;

    private int contactNo;

    private int adharCard;

    private String emailId;

    private Date birthDate;

    private int monthlySalary;
}
