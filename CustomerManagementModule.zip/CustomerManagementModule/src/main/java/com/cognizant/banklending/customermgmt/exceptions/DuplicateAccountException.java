package com.cognizant.banklending.customermgmt.exceptions;

public class DuplicateAccountException extends RuntimeException{
    public DuplicateAccountException(String message){
        super(message);
    }
}
