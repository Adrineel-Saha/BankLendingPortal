package com.cognizant.banklending.customermgmt.dtos;

import lombok.Data;

@Data
public class UserRequestDTO {
    private String userName;

    private String password;
}
