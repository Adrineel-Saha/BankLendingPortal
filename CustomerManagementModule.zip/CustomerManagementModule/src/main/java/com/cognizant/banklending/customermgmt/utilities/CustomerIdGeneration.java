package com.cognizant.banklending.customermgmt.utilities;

import java.util.Random;

public class CustomerIdGeneration {
    public static String generateCustomerId(String custLastName) {
        String formattedLastName=custLastName.substring(0,Math.min(2, custLastName.length())).toUpperCase();
        int randomNumber=new Random().nextInt(9000)+1000;
        String formattedNumber=String.valueOf(randomNumber);
        return formattedLastName+formattedNumber;
    }
}
