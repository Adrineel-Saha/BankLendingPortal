package com.cognizant.banklending.customermgmt.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ReducedPaymentDTO {
    private String loanAppId;
    private int monthNo;
    private int installment;
    private int interestRate;
    private int loanAmt;
    private int noOfYears;
    private int pOutstandingBeginOfMonth;
    private int pRepayment;
    private int prOutstandingEndOfMonth;
    private int reducedPayment;
}
