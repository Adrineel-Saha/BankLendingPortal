package com.cognizant.banklending.customermgmt.services;

import com.cognizant.banklending.customermgmt.dtos.CustomerDTO;
import com.cognizant.banklending.customermgmt.entities.CustomerMaster;
import com.cognizant.banklending.customermgmt.entities.LoanApplication;
import com.cognizant.banklending.customermgmt.repositories.CustomerMasterRepository;
import com.cognizant.banklending.customermgmt.repositories.LoanApplicationRepository;
import com.cognizant.banklending.customermgmt.utilities.CustomerIdGeneration;
import com.cognizant.banklending.customermgmt.utilities.CustomerMasterValidation;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

@Service
public class CustomerMasterServiceImpl implements CustomerMasterService{
    @Autowired
    private CustomerMasterRepository customerMasterRepository;
    @Autowired
    private LoanApplicationRepository loanApplicationRepository;
    @Autowired
    private ModelMapper modelMapper;

    @Override
    public CustomerDTO addCustomer(CustomerDTO customerDTO) {
        CustomerMasterValidation customerMasterValidation=new CustomerMasterValidation();
        customerMasterValidation.validateCustomerMaster(customerDTO, customerMasterRepository);
        customerDTO.setCustId(CustomerIdGeneration.generateCustomerId(customerDTO.getCustLastName()));

        CustomerMaster customerMaster=modelMapper.map(customerDTO,CustomerMaster.class);
        CustomerMaster newCustomerMaster=customerMasterRepository.save(customerMaster);

        CustomerDTO newCustomerDTO=modelMapper.map(newCustomerMaster,CustomerDTO.class);
        return newCustomerDTO;
    }

    @Override
    public List<CustomerDTO> getAllCustomers() {
        Iterable<CustomerMaster> customerMasterIterable=customerMasterRepository.findAll();
        List<CustomerDTO> customerDTOList=new ArrayList<>();
        Iterator<CustomerMaster> customerMasterIterator=customerMasterIterable.iterator();

        while(customerMasterIterator.hasNext()) {
            CustomerMaster customerMaster=customerMasterIterator.next();
            CustomerDTO customerDTO=modelMapper.map(customerMaster, CustomerDTO.class);
            customerDTOList.add(customerDTO);
        }

        if(customerDTOList.isEmpty()) {
            throw new RuntimeException("List is empty");
        }
        return customerDTOList;
    }

    @Override
    public CustomerDTO getCustomerById(String custId) {
        Optional<CustomerMaster> customerMasterOptional=customerMasterRepository.findById(custId);
        CustomerMaster existingCustomerMaster = customerMasterOptional.orElseThrow(()->new RuntimeException("Customer not found with id: "+ custId));
        CustomerDTO customerDTO=modelMapper.map(existingCustomerMaster,CustomerDTO.class);
        return customerDTO;
    }

    @Override
    public CustomerDTO updateCustomer(String custId, CustomerDTO customerDTO) {
        CustomerMasterValidation customerMasterValidation=new CustomerMasterValidation();
        customerMasterValidation.validateCustomerMaster(customerDTO, customerMasterRepository);

        Optional<CustomerMaster> customerMasterOptional=customerMasterRepository.findById(custId);
        CustomerMaster existingCustomerMaster = customerMasterOptional.orElseThrow(()->new RuntimeException("Customer not found with id: "+ custId));

        existingCustomerMaster.setCustFirstName(customerDTO.getCustFirstName());
        existingCustomerMaster.setCustLastName(customerDTO.getCustLastName());
        existingCustomerMaster.setAddress(customerDTO.getAddress());
        existingCustomerMaster.setCity(customerDTO.getCity());
        existingCustomerMaster.setContactNo(customerDTO.getContactNo());
        existingCustomerMaster.setAdharCard(customerDTO.getAdharCard());
        existingCustomerMaster.setEmailId(customerDTO.getEmailId());
        existingCustomerMaster.setBirthDate(customerDTO.getBirthDate());
        existingCustomerMaster.setMonthlySalary(customerDTO.getMonthlySalary());

        CustomerMaster updatedCustomerMaster = customerMasterRepository.save(existingCustomerMaster);

        CustomerDTO newcustomerDTO=modelMapper.map(updatedCustomerMaster,CustomerDTO.class);
        return newcustomerDTO;
    }

    @Override
    public List<CustomerDTO> getAllCustomersByStatus(String status) {
        List<LoanApplication> loanApplicationList=loanApplicationRepository.findByAppStatus(status);
        Iterator<LoanApplication> loanApplicationIterator=loanApplicationList.iterator();

        List<CustomerDTO> customerDTOList=new ArrayList<>();

        while(loanApplicationIterator.hasNext()) {
            LoanApplication loanApplication=loanApplicationIterator.next();
            CustomerMaster customerMaster=loanApplication.getCustomerMaster();

            CustomerDTO customerDTO=modelMapper.map(customerMaster,CustomerDTO.class);
            customerDTOList.add(customerDTO);
        }

        if(customerDTOList.isEmpty()) {
            throw new RuntimeException("List is empty");
        }
        return customerDTOList;
    }
}
