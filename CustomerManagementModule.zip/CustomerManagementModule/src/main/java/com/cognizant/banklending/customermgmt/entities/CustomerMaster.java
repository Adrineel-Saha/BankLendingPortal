package com.cognizant.banklending.customermgmt.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Entity
@Table(name="Customer_Master")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CustomerMaster {
    @Id
    @Column(name="Cust_Id")
    private String custId;

    @Column(name="Cust_First_Name")
    private String custFirstName;

    @Column(name="Cust_Last_Name")
    private String custLastName;

    @Column(name="Address")
    private String address;

    @Column(name="City")
    private String city;

    @Column(name="Contact_No")
    private int contactNo;

    @Column(name="Adhar_Card")
    private int adharCard;

    @Column(name="Email_Id")
    private String emailId;

    @Column(name="Birth_Date")
    @Temporal(TemporalType.DATE)
    private Date birthDate;

    @Column(name="Monthly_Salary")
    private int monthlySalary;
}
