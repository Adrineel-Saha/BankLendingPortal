package com.cognizant.banklending.customermgmt.exceptions;

public class LoanUnderProcessingExcepttion extends RuntimeException {
    public LoanUnderProcessingExcepttion(String message) {
        super(message);
    }
}
