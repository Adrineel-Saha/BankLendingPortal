package com.cognizant.banklending.customermgmt.services;

import com.cognizant.banklending.customermgmt.dtos.CustomerDTO;
import com.cognizant.banklending.customermgmt.dtos.LoanAppDTO;
import com.cognizant.banklending.customermgmt.entities.CustomerMaster;
import com.cognizant.banklending.customermgmt.entities.LoanApplication;
import com.cognizant.banklending.customermgmt.exceptions.LoanUnderProcessingExcepttion;
import com.cognizant.banklending.customermgmt.repositories.CustomerMasterRepository;
import com.cognizant.banklending.customermgmt.repositories.LoanApplicationRepository;
import com.cognizant.banklending.customermgmt.utilities.CustomerIdGeneration;
import com.cognizant.banklending.customermgmt.utilities.CustomerMasterValidation;
import com.cognizant.banklending.customermgmt.utilities.LoanAppIdGeneration;
import com.cognizant.banklending.customermgmt.utilities.LoanApplicationValidation;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class LoanApplicationServiceImpl implements LoanApplicationService{
    @Autowired
    private LoanApplicationRepository loanApplicationRepository;
    @Autowired
    private CustomerMasterRepository customerMasterRepository;
    @Autowired
    private ModelMapper modelMapper;


    @Override
    public List<LoanAppDTO> getAllLoanApplicationsByDate(Date date) {
        List<LoanApplication> loanApplicationList=loanApplicationRepository.findByLoanAppDate(date);
        List<LoanAppDTO> loanAppDTOList=new ArrayList<>();
        Iterator<LoanApplication> loanApplicationIterator=loanApplicationList.iterator();

        while(loanApplicationIterator.hasNext()) {
            LoanApplication loanApplication=loanApplicationIterator.next();
            LoanAppDTO loanAppDTO=modelMapper.map(loanApplication, LoanAppDTO.class);
            loanAppDTO.setCustId(loanApplication.getCustomerMaster().getCustId());
            loanAppDTOList.add(loanAppDTO);
        }

        if(loanAppDTOList.isEmpty()) {
            throw new RuntimeException("List is empty");
        }
        return loanAppDTOList;
    }

    @Override
    public LoanAppDTO updateLoanApplication(String loanAppId, LoanAppDTO loanAppDTO) {
        LoanApplicationValidation loanApplicationValidation=new LoanApplicationValidation();
        loanApplicationValidation.validateLoanApplication(loanAppDTO);

        Optional<LoanApplication> loanApplicationOptional=loanApplicationRepository.findById(loanAppId);
        LoanApplication existingLoanApplication = loanApplicationOptional.orElseThrow(()->new RuntimeException("Loan not found with id: "+ loanAppId));

        if(existingLoanApplication.getAppStatus().equals("NewLoan")){
            existingLoanApplication.setLoanAmt(loanAppDTO.getLoanAmt());
            existingLoanApplication.setNoOfYears(loanAppDTO.getNoOfYears());
            existingLoanApplication.setTypeOfLoan(loanAppDTO.getTypeOfLoan());
        }
        else if(existingLoanApplication.getAppStatus().equals("Approved")){
            existingLoanApplication.setStatus(loanAppDTO.getStatus());
        }
        else{
            throw new LoanUnderProcessingExcepttion("Customer can't update loan record");
        }

        LoanApplication updatedLoanApplication=loanApplicationRepository.save(existingLoanApplication);
        LoanAppDTO updatedloanAppDTO=modelMapper.map(updatedLoanApplication,LoanAppDTO.class);
        updatedloanAppDTO.setCustId(existingLoanApplication.getCustomerMaster().getCustId());
        return updatedloanAppDTO;
    }

    @Override
    public LoanAppDTO getLoanApplicationById(String loanAppId) {
        Optional<LoanApplication> loanApplicationOptional=loanApplicationRepository.findById(loanAppId);
        LoanApplication existingLoanApplication = loanApplicationOptional.orElseThrow(()->new RuntimeException("Loan not found with id: "+ loanAppId));
        LoanAppDTO loanAppDTO=modelMapper.map(existingLoanApplication,LoanAppDTO.class);
        loanAppDTO.setCustId(existingLoanApplication.getCustomerMaster().getCustId());
        return loanAppDTO;
    }

    @Override
    public LoanAppDTO getLoanApplicationByStatus(String loanAppId) {
        Optional<LoanApplication> loanApplicationOptional=loanApplicationRepository.findById(loanAppId);
        LoanApplication existingLoanApplication = loanApplicationOptional.orElseThrow(()->new RuntimeException("Loan not found with id: "+ loanAppId));
        if(existingLoanApplication.getStatus().equals("accepted") || existingLoanApplication.getStatus().equals("rejected")){
            LoanAppDTO loanAppDTO=modelMapper.map(existingLoanApplication,LoanAppDTO.class);
            loanAppDTO.setCustId(existingLoanApplication.getCustomerMaster().getCustId());
            return loanAppDTO;
        }
        else{
            throw new RuntimeException("Customer hasn't accepted or rejected the loan");
        }
    }

    @Override
    public LoanAppDTO addLoanApplication(LoanAppDTO loanAppDTO) {
        LoanApplicationValidation loanApplicationValidation=new LoanApplicationValidation();
        loanApplicationValidation.validateLoanApplication(loanAppDTO);
        loanAppDTO.setLoanAppId(LoanAppIdGeneration.generateLoanAppId(loanAppDTO.getTypeOfLoan()));

        LoanApplication loanApplication=modelMapper.map(loanAppDTO,LoanApplication.class);

        Optional<CustomerMaster> customerMasterOptional=customerMasterRepository.findById(loanAppDTO.getCustId());
        CustomerMaster customerMaster=customerMasterOptional.orElseThrow(()->new RuntimeException("Customer not found with id: "+ loanAppDTO.getCustId()));

        loanApplication.setCustomerMaster(customerMaster);

        LoanApplication newLoanApplication=loanApplicationRepository.save(loanApplication);

        LoanAppDTO newLoanAppDTO=modelMapper.map(newLoanApplication,LoanAppDTO.class);
        newLoanAppDTO.setCustId(newLoanApplication.getCustomerMaster().getCustId());

//        System.out.println(newLoanAppDTO.getCustId());
        return newLoanAppDTO;
    }
}
