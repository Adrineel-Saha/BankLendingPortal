package com.cognizant.banklending.customermgmt.dtos;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.Column;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.time.DateUtils;
import org.hibernate.validator.constraints.Length;

import java.util.Calendar;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LoanAppDTO {
//    @JsonIgnore
    private String loanAppId;

    @Length(min=6,max=6)
    private String custId;

    private int loanAmt;

    private int noOfYears;

    private String purpose;

    @Pattern(regexp="^(NewLoan|Canceled|Approved|Sanctioned)$")
    private String appStatus;

    private String typeOfLoan;

    @Temporal(TemporalType.DATE)
    private Date loanAppDate;

    @Pattern(regexp="^(accepted|rejected|no status)$")
    private String status;

    @JsonIgnore
    @AssertTrue(message="Loan_App_Date should be CURRENTDATE")
    public boolean isLoanAppDateEqualsCurrentDate() {
        return DateUtils.truncate(loanAppDate, Calendar.DAY_OF_MONTH).equals(DateUtils.truncate(new Date(), Calendar.DAY_OF_MONTH));
    }
}
