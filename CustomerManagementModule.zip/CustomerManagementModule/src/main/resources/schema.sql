CREATE TABLE Customer_Master (
    Cust_Id VARCHAR(6) CHECK (Length(Cust_Id)=6),
    Cust_First_Name VARCHAR(100) NOT NULL CHECK (LENGTH(Cust_First_Name) >= 3),
    Cust_Last_Name VARCHAR(100) NOT NULL CHECK (LENGTH(Cust_Last_Name) >= 3),
    Address VARCHAR(255),
    City VARCHAR(100),
    Contact_No INTEGER,
    Adhar_Card INTEGER,
    Email_Id VARCHAR(100),
    Birth_Date DATE,
    Monthly_Salary INTEGER,
    CONSTRAINT PK1 PRIMARY KEY (Cust_Id)
);

CREATE TABLE Loan_Application (
    Loan_App_Id VARCHAR(50),
    Loan_Amt INTEGER NOT NULL,
    No_Of_Years INTEGER NOT NULL,
    Purpose VARCHAR(255),
    App_Status VARCHAR(20) CHECK (App_Status IN ('NewLoan', 'Canceled', 'Approved', 'Sanctioned')),
    Type_Of_Loan VARCHAR(50),
    Loan_App_Date DATE NOT NULL DEFAULT (CURDATE()),
    Status VARCHAR(20) CHECK (Status IN ('accepted', 'rejected', 'no status')),
    Cust_Id VARCHAR(6),
    CONSTRAINT PK2 PRIMARY KEY (Loan_App_Id),
    CONSTRAINT FK2 FOREIGN KEY (Cust_Id) REFERENCES Customer_Master(Cust_Id)
);

CREATE TABLE Loan_App_Detail_Master (
    Id INTEGER,
    Month_No INTEGER NOT NULL,
    Installment INTEGER NOT NULL,
    Interest_Rate INTEGER NOT NULL,
    P_Outstanding_Begin_Of_Month INTEGER NOT NULL,
    P_Repayment INTEGER NOT NULL,
    Pr_Outstanding_End_Of_Month INTEGER NOT NULL,
    Last_Date_Of_Install_Pay DATE,
    Loan_App_Id VARCHAR(50),
    CONSTRAINT PK3 PRIMARY KEY (Id),
    CONSTRAINT FK3 FOREIGN KEY (Loan_App_Id) REFERENCES Loan_Application(Loan_App_Id)
);

CREATE TABLE Users (
    User_Name VARCHAR(40),
    Password VARCHAR(40) NOT NULL,
    Role VARCHAR(40) NOT NULL,
    Is_Account_Locked boolean,
    CONSTRAINT PK4 PRIMARY KEY (User_Name)
);