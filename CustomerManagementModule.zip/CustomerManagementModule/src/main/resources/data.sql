INSERT INTO Customer_Master (Cust_Id, Cust_First_Name, Cust_Last_Name, Address, City, Contact_No, Adhar_Card, Email_Id, Birth_Date, Monthly_Salary) VALUES
('CUST01', 'Adrineel', 'Saha', '123 Street', 'Asansol', 1234567890, 1456789012, 'adrineel.saha@cognizant.com', '2001-10-18', 65000),
('CUST02', 'Arunabh', 'Kalita', '456 Avenue', 'Dibrugarh', 1876543210, 1567890123, 'arunabh.kalita@cognizant.com', '2000-05-15', 60000),
('CUST03', 'Yash', 'Biswakarma', '789 Boulevard', 'Darjeeling', 1122334455, 1456701234, 'yash.biswakarma@cognizant.com', '2001-09-29', 55000),
('CUST04', 'Sayan', 'Kashyapi', '101 Road', 'Kolkata', 1677889900, 1678901235, 'sayan.kashyapi@cognizant.com', '2002-05-19', 48000),
('CUST05', 'Ayan', 'Chakraborty', '202 Lane', 'Kolkata', 1988776655, 1789012456, 'ayan.chakraborty@cognizant.com', '2001-04-17', 62000);

INSERT INTO Loan_Application (Loan_App_Id, Loan_Amt, No_Of_Years, Purpose, App_Status, Type_Of_Loan, Loan_App_Date, Status, Cust_Id) VALUES
('LOAN001', 200000, 5, 'Home Renovation', 'NewLoan', 'Home Loan', CURRENT_DATE, 'accepted', 'CUST01'),
('LOAN002', 150000, 3, 'Car Purchase', 'Approved', 'Auto Loan', CURRENT_DATE, 'no status', 'CUST02'),
('LOAN003', 250000, 7, 'Business Expansion', 'Sanctioned', 'Business Loan', CURRENT_DATE, 'rejected', 'CUST03'),
('LOAN004', 100000, 2, 'Education', 'NewLoan', 'Education Loan', CURRENT_DATE, 'accepted', 'CUST04'),
('LOAN005', 300000, 10, 'Real Estate', 'Approved', 'Mortgage Loan', CURRENT_DATE, 'rejected', 'CUST05');

INSERT INTO Loan_App_Detail_Master (Id, Month_No, Installment, Interest_Rate, P_Outstanding_Begin_Of_Month, P_Repayment, Pr_Outstanding_End_Of_Month, Last_Date_Of_Install_Pay, Loan_App_Id) VALUES
(1, 1, 20000, 8, 200000, 15000, 185000, '2022-01-31', 'LOAN001'),
(2, 2, 20000, 7, 185000, 15000, 170000, '2022-02-28', 'LOAN001'),
(3, 1, 15000, 6, 150000, 10000, 140000, '2022-01-31', 'LOAN002'),
(4, 3, 15000, 5, 140000, 10000, 130000, '2022-03-31', 'LOAN002'),
(5, 1, 30000, 6, 300000, 20000, 280000, '2022-01-31', 'LOAN005');

INSERT INTO Users (User_Name,Password,Role,Is_Account_Locked) VALUES
('Adrineel','Adri@2001','Customer',false),
('Ayan','Ayan#1704','Banker',false),
('Ashish','Ashish#1803','Customer',false),
('Rakesh','Rakesh@2000','Banker',false),
('Sagar','Sagar#2902','Customer',false);
